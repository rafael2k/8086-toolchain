/* This file auto-generated from insns.dat by insns.pl - don't edit it */

#include "nasm.h"
#include "insns.h"

static const struct itemplate instrux[] = {
    /*    0 */ {I_RESB, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+3155, IF_8086},
    /*    1 */ {I_AAA, 0, {0,0,0,0,0}, nasm_bytecodes+4009, IF_8086|IF_NOLONG},
    /*    2 */ {I_AAD, 0, {0,0,0,0,0}, nasm_bytecodes+2989, IF_8086|IF_NOLONG},
    /*    3 */ {I_AAD, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2993, IF_8086|IF_SB|IF_NOLONG},
    /*    4 */ {I_AAM, 0, {0,0,0,0,0}, nasm_bytecodes+2997, IF_8086|IF_NOLONG},
    /*    5 */ {I_AAM, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+3001, IF_8086|IF_SB|IF_NOLONG},
    /*    6 */ {I_AAS, 0, {0,0,0,0,0}, nasm_bytecodes+4012, IF_8086|IF_NOLONG},
    /*    7 */ {I_ADC, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3005, IF_8086|IF_SM},
    /*    8 */ {I_ADC, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3005, IF_8086},
    /*    9 */ {I_ADC, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1524, IF_8086|IF_SM},
    /*   10 */ {I_ADC, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1524, IF_8086},
    /*   11 */ {I_ADC, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1529, IF_386|IF_SM},
    /*   12 */ {I_ADC, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1529, IF_386},
    /*   13 */ {I_ADC, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3009, IF_8086|IF_SM},
    /*   14 */ {I_ADC, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3009, IF_8086},
    /*   15 */ {I_ADC, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1534, IF_8086|IF_SM},
    /*   16 */ {I_ADC, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1534, IF_8086},
    /*   17 */ {I_ADC, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1539, IF_386|IF_SM},
    /*   18 */ {I_ADC, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1539, IF_386},
    /*   19 */ {I_ADC, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+684, IF_8086},
    /*   20 */ {I_ADC, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+690, IF_386},
    /*   21 */ {I_ADC, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3013, IF_8086|IF_SM},
    /*   22 */ {I_ADC, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+684, IF_8086|IF_SM},
    /*   23 */ {I_ADC, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+1544, IF_8086|IF_SM},
    /*   24 */ {I_ADC, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+690, IF_386|IF_SM},
    /*   25 */ {I_ADC, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+1549, IF_386|IF_SM},
    /*   26 */ {I_ADC, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+1554, IF_8086|IF_SM},
    /*   27 */ {I_ADC, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+696, IF_8086|IF_SM},
    /*   28 */ {I_ADC, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+702, IF_386|IF_SM},
    /*   29 */ {I_ADC, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1554, IF_8086|IF_SM},
    /*   30 */ {I_ADC, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+696, IF_8086|IF_SM},
    /*   31 */ {I_ADC, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+702, IF_386|IF_SM},
    /*   32 */ {I_ADD, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3017, IF_8086|IF_SM},
    /*   33 */ {I_ADD, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3017, IF_8086},
    /*   34 */ {I_ADD, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1559, IF_8086|IF_SM},
    /*   35 */ {I_ADD, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1559, IF_8086},
    /*   36 */ {I_ADD, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1564, IF_386|IF_SM},
    /*   37 */ {I_ADD, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1564, IF_386},
    /*   38 */ {I_ADD, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3021, IF_8086|IF_SM},
    /*   39 */ {I_ADD, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3021, IF_8086},
    /*   40 */ {I_ADD, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1569, IF_8086|IF_SM},
    /*   41 */ {I_ADD, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1569, IF_8086},
    /*   42 */ {I_ADD, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1574, IF_386|IF_SM},
    /*   43 */ {I_ADD, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1574, IF_386},
    /*   44 */ {I_ADD, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+708, IF_8086},
    /*   45 */ {I_ADD, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+714, IF_386},
    /*   46 */ {I_ADD, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3025, IF_8086|IF_SM},
    /*   47 */ {I_ADD, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+708, IF_8086|IF_SM},
    /*   48 */ {I_ADD, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+1579, IF_8086|IF_SM},
    /*   49 */ {I_ADD, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+714, IF_386|IF_SM},
    /*   50 */ {I_ADD, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+1584, IF_386|IF_SM},
    /*   51 */ {I_ADD, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+1589, IF_8086|IF_SM},
    /*   52 */ {I_ADD, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+720, IF_8086|IF_SM},
    /*   53 */ {I_ADD, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+726, IF_386|IF_SM},
    /*   54 */ {I_ADD, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1589, IF_8086|IF_SM},
    /*   55 */ {I_ADD, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+720, IF_8086|IF_SM},
    /*   56 */ {I_ADD, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+726, IF_386|IF_SM},
    /*   57 */ {I_AND, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3029, IF_8086|IF_SM},
    /*   58 */ {I_AND, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3029, IF_8086},
    /*   59 */ {I_AND, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1594, IF_8086|IF_SM},
    /*   60 */ {I_AND, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1594, IF_8086},
    /*   61 */ {I_AND, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1599, IF_386|IF_SM},
    /*   62 */ {I_AND, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1599, IF_386},
    /*   63 */ {I_AND, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3033, IF_8086|IF_SM},
    /*   64 */ {I_AND, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3033, IF_8086},
    /*   65 */ {I_AND, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1604, IF_8086|IF_SM},
    /*   66 */ {I_AND, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1604, IF_8086},
    /*   67 */ {I_AND, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1609, IF_386|IF_SM},
    /*   68 */ {I_AND, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1609, IF_386},
    /*   69 */ {I_AND, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+732, IF_8086},
    /*   70 */ {I_AND, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+738, IF_386},
    /*   71 */ {I_AND, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3037, IF_8086|IF_SM},
    /*   72 */ {I_AND, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+732, IF_8086|IF_SM},
    /*   73 */ {I_AND, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+1614, IF_8086|IF_SM},
    /*   74 */ {I_AND, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+738, IF_386|IF_SM},
    /*   75 */ {I_AND, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+1619, IF_386|IF_SM},
    /*   76 */ {I_AND, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+1624, IF_8086|IF_SM},
    /*   77 */ {I_AND, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+744, IF_8086|IF_SM},
    /*   78 */ {I_AND, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+750, IF_386|IF_SM},
    /*   79 */ {I_AND, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1624, IF_8086|IF_SM},
    /*   80 */ {I_AND, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+744, IF_8086|IF_SM},
    /*   81 */ {I_AND, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+750, IF_386|IF_SM},
    /*   82 */ {I_ARPL, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+3041, IF_286|IF_PROT|IF_SM|IF_NOLONG},
    /*   83 */ {I_ARPL, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+3041, IF_286|IF_PROT|IF_NOLONG},
    /*   84 */ {I_BOUND, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1629, IF_186|IF_NOLONG},
    /*   85 */ {I_BOUND, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1634, IF_386|IF_NOLONG},
    /*   86 */ {I_BSF, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+756, IF_386|IF_SM},
    /*   87 */ {I_BSF, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+756, IF_386},
    /*   88 */ {I_BSF, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+762, IF_386|IF_SM},
    /*   89 */ {I_BSF, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+762, IF_386},
    /*   90 */ {I_BSR, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+768, IF_386|IF_SM},
    /*   91 */ {I_BSR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+768, IF_386},
    /*   92 */ {I_BSR, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+774, IF_386|IF_SM},
    /*   93 */ {I_BSR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+774, IF_386},
    /*   94 */ {I_BSWAP, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+780, IF_486},
    /*   95 */ {I_BT, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+786, IF_386|IF_SM},
    /*   96 */ {I_BT, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+786, IF_386},
    /*   97 */ {I_BT, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+792, IF_386|IF_SM},
    /*   98 */ {I_BT, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+792, IF_386},
    /*   99 */ {I_BT, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+152, IF_386|IF_SB},
    /*  100 */ {I_BT, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+159, IF_386|IF_SB},
    /*  101 */ {I_BTC, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+798, IF_386|IF_SM},
    /*  102 */ {I_BTC, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+798, IF_386},
    /*  103 */ {I_BTC, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+804, IF_386|IF_SM},
    /*  104 */ {I_BTC, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+804, IF_386},
    /*  105 */ {I_BTC, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+166, IF_386|IF_SB},
    /*  106 */ {I_BTC, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+173, IF_386|IF_SB},
    /*  107 */ {I_BTR, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+810, IF_386|IF_SM},
    /*  108 */ {I_BTR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+810, IF_386},
    /*  109 */ {I_BTR, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+816, IF_386|IF_SM},
    /*  110 */ {I_BTR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+816, IF_386},
    /*  111 */ {I_BTR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+180, IF_386|IF_SB},
    /*  112 */ {I_BTR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+187, IF_386|IF_SB},
    /*  113 */ {I_BTS, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+822, IF_386|IF_SM},
    /*  114 */ {I_BTS, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+822, IF_386},
    /*  115 */ {I_BTS, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+828, IF_386|IF_SM},
    /*  116 */ {I_BTS, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+828, IF_386},
    /*  117 */ {I_BTS, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+194, IF_386|IF_SB},
    /*  118 */ {I_BTS, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+201, IF_386|IF_SB},
    /*  119 */ {I_CALL, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+1639, IF_8086},
    /*  120 */ {I_CALL, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+1639, IF_8086},
    /*  121 */ {I_CALL, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+1644, IF_8086},
    /*  122 */ {I_CALL, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+1644, IF_8086},
    /*  123 */ {I_CALL, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+1649, IF_386},
    /*  124 */ {I_CALL, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+1649, IF_386},
    /*  125 */ {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+852, IF_8086|IF_NOLONG},
    /*  126 */ {I_CALL, 2, {IMMEDIATE|BITS16|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+858, IF_8086|IF_NOLONG},
    /*  127 */ {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+858, IF_8086|IF_NOLONG},
    /*  128 */ {I_CALL, 2, {IMMEDIATE|BITS32|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+864, IF_386|IF_NOLONG},
    /*  129 */ {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+864, IF_386|IF_NOLONG},
    /*  130 */ {I_CALL, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+1654, IF_8086|IF_NOLONG},
    /*  131 */ {I_CALL, 1, {MEMORY|BITS16|FAR,0,0,0,0}, nasm_bytecodes+1659, IF_8086},
    /*  132 */ {I_CALL, 1, {MEMORY|BITS32|FAR,0,0,0,0}, nasm_bytecodes+1664, IF_386},
    /*  133 */ {I_CALL, 1, {MEMORY|NEAR,0,0,0,0}, nasm_bytecodes+1669, IF_8086},
    /*  134 */ {I_CALL, 1, {MEMORY|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+1674, IF_8086},
    /*  135 */ {I_CALL, 1, {MEMORY|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+1679, IF_386|IF_NOLONG},
    /*  136 */ {I_CALL, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1674, IF_8086},
    /*  137 */ {I_CALL, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1679, IF_386|IF_NOLONG},
    /*  138 */ {I_CALL, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+1669, IF_8086},
    /*  139 */ {I_CALL, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+1674, IF_8086},
    /*  140 */ {I_CALL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+1679, IF_386|IF_NOLONG},
    /*  141 */ {I_CBW, 0, {0,0,0,0,0}, nasm_bytecodes+3053, IF_8086},
    /*  142 */ {I_CDQ, 0, {0,0,0,0,0}, nasm_bytecodes+3057, IF_386},
    /*  143 */ {I_CLC, 0, {0,0,0,0,0}, nasm_bytecodes+4015, IF_8086},
    /*  144 */ {I_CLD, 0, {0,0,0,0,0}, nasm_bytecodes+4018, IF_8086},
    /*  145 */ {I_CLI, 0, {0,0,0,0,0}, nasm_bytecodes+4021, IF_8086},
    /*  146 */ {I_CLTS, 0, {0,0,0,0,0}, nasm_bytecodes+3061, IF_286|IF_PRIV},
    /*  147 */ {I_CMC, 0, {0,0,0,0,0}, nasm_bytecodes+4024, IF_8086},
    /*  148 */ {I_CMP, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3065, IF_8086|IF_SM},
    /*  149 */ {I_CMP, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3065, IF_8086},
    /*  150 */ {I_CMP, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1684, IF_8086|IF_SM},
    /*  151 */ {I_CMP, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1684, IF_8086},
    /*  152 */ {I_CMP, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1689, IF_386|IF_SM},
    /*  153 */ {I_CMP, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1689, IF_386},
    /*  154 */ {I_CMP, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3069, IF_8086|IF_SM},
    /*  155 */ {I_CMP, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3069, IF_8086},
    /*  156 */ {I_CMP, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1694, IF_8086|IF_SM},
    /*  157 */ {I_CMP, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1694, IF_8086},
    /*  158 */ {I_CMP, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1699, IF_386|IF_SM},
    /*  159 */ {I_CMP, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1699, IF_386},
    /*  160 */ {I_CMP, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+870, IF_8086},
    /*  161 */ {I_CMP, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+876, IF_386},
    /*  162 */ {I_CMP, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3073, IF_8086|IF_SM},
    /*  163 */ {I_CMP, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+870, IF_8086|IF_SM},
    /*  164 */ {I_CMP, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+1704, IF_8086|IF_SM},
    /*  165 */ {I_CMP, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+876, IF_386|IF_SM},
    /*  166 */ {I_CMP, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+1709, IF_386|IF_SM},
    /*  167 */ {I_CMP, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+1714, IF_8086|IF_SM},
    /*  168 */ {I_CMP, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+882, IF_8086|IF_SM},
    /*  169 */ {I_CMP, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+888, IF_386|IF_SM},
    /*  170 */ {I_CMP, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1714, IF_8086|IF_SM},
    /*  171 */ {I_CMP, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+882, IF_8086|IF_SM},
    /*  172 */ {I_CMP, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+888, IF_386|IF_SM},
    /*  173 */ {I_CMPSB, 0, {0,0,0,0,0}, nasm_bytecodes+3077, IF_8086},
    /*  174 */ {I_CMPSD, 0, {0,0,0,0,0}, nasm_bytecodes+1719, IF_386},
    /*  175 */ {I_CMPSW, 0, {0,0,0,0,0}, nasm_bytecodes+1724, IF_8086},
    /*  176 */ {I_CMPXCHG, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+1729, IF_PENT|IF_SM},
    /*  177 */ {I_CMPXCHG, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+1729, IF_PENT},
    /*  178 */ {I_CMPXCHG, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+894, IF_PENT|IF_SM},
    /*  179 */ {I_CMPXCHG, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+894, IF_PENT},
    /*  180 */ {I_CMPXCHG, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+900, IF_PENT|IF_SM},
    /*  181 */ {I_CMPXCHG, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+900, IF_PENT},
    /*  182 */ {I_CMPXCHG8B, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+1739, IF_PENT},
    /*  183 */ {I_CPUID, 0, {0,0,0,0,0}, nasm_bytecodes+3081, IF_PENT},
    /*  184 */ {I_CPU_READ, 0, {0,0,0,0,0}, nasm_bytecodes+3085, IF_PENT|IF_CYRIX},
    /*  185 */ {I_CPU_WRITE, 0, {0,0,0,0,0}, nasm_bytecodes+3089, IF_PENT|IF_CYRIX},
    /*  186 */ {I_CWD, 0, {0,0,0,0,0}, nasm_bytecodes+3093, IF_8086},
    /*  187 */ {I_CWDE, 0, {0,0,0,0,0}, nasm_bytecodes+3097, IF_386},
    /*  188 */ {I_DAA, 0, {0,0,0,0,0}, nasm_bytecodes+4027, IF_8086|IF_NOLONG},
    /*  189 */ {I_DAS, 0, {0,0,0,0,0}, nasm_bytecodes+4030, IF_8086|IF_NOLONG},
    /*  190 */ {I_DEC, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+3101, IF_8086|IF_NOLONG},
    /*  191 */ {I_DEC, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+3105, IF_386|IF_NOLONG},
    /*  192 */ {I_DEC, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3109, IF_8086},
    /*  193 */ {I_DEC, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1744, IF_8086},
    /*  194 */ {I_DEC, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1749, IF_386},
    /*  195 */ {I_DIV, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3113, IF_8086},
    /*  196 */ {I_DIV, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1754, IF_8086},
    /*  197 */ {I_DIV, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1759, IF_386},
    /*  198 */ {I_DMINT, 0, {0,0,0,0,0}, nasm_bytecodes+3117, IF_P6|IF_CYRIX},
    /*  199 */ {I_EMMS, 0, {0,0,0,0,0}, nasm_bytecodes+3121, IF_PENT|IF_MMX},
    /*  200 */ {I_ENTER, 2, {IMMEDIATE,IMMEDIATE,0,0,0}, nasm_bytecodes+1764, IF_186},
    /*  201 */ {I_EQU, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+4087, IF_8086},
    /*  202 */ {I_EQU, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+4087, IF_8086},
    /*  203 */ {I_F2XM1, 0, {0,0,0,0,0}, nasm_bytecodes+3125, IF_8086|IF_FPU},
    /*  204 */ {I_FABS, 0, {0,0,0,0,0}, nasm_bytecodes+3129, IF_8086|IF_FPU},
    /*  205 */ {I_FADD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3133, IF_8086|IF_FPU},
    /*  206 */ {I_FADD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3137, IF_8086|IF_FPU},
    /*  207 */ {I_FADD, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+1769, IF_8086|IF_FPU},
    /*  208 */ {I_FADD, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1774, IF_8086|IF_FPU},
    /*  209 */ {I_FADD, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1769, IF_8086|IF_FPU},
    /*  210 */ {I_FADD, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1779, IF_8086|IF_FPU},
    /*  211 */ {I_FADDP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1784, IF_8086|IF_FPU},
    /*  212 */ {I_FADDP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1784, IF_8086|IF_FPU},
    /*  213 */ {I_FBLD, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+3145, IF_8086|IF_FPU},
    /*  214 */ {I_FBLD, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+3145, IF_8086|IF_FPU},
    /*  215 */ {I_FBSTP, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+3149, IF_8086|IF_FPU},
    /*  216 */ {I_FBSTP, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+3149, IF_8086|IF_FPU},
    /*  217 */ {I_FCHS, 0, {0,0,0,0,0}, nasm_bytecodes+3153, IF_8086|IF_FPU},
    /*  218 */ {I_FCLEX, 0, {0,0,0,0,0}, nasm_bytecodes+1789, IF_8086|IF_FPU},
    /*  219 */ {I_FCMOVB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1794, IF_P6|IF_FPU},
    /*  220 */ {I_FCMOVB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1799, IF_P6|IF_FPU},
    /*  221 */ {I_FCMOVBE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1804, IF_P6|IF_FPU},
    /*  222 */ {I_FCMOVBE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1809, IF_P6|IF_FPU},
    /*  223 */ {I_FCMOVE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1814, IF_P6|IF_FPU},
    /*  224 */ {I_FCMOVE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1819, IF_P6|IF_FPU},
    /*  225 */ {I_FCMOVNB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1824, IF_P6|IF_FPU},
    /*  226 */ {I_FCMOVNB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1829, IF_P6|IF_FPU},
    /*  227 */ {I_FCMOVNBE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1834, IF_P6|IF_FPU},
    /*  228 */ {I_FCMOVNBE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1839, IF_P6|IF_FPU},
    /*  229 */ {I_FCMOVNE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1844, IF_P6|IF_FPU},
    /*  230 */ {I_FCMOVNE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1849, IF_P6|IF_FPU},
    /*  231 */ {I_FCMOVNU, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1854, IF_P6|IF_FPU},
    /*  232 */ {I_FCMOVNU, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1859, IF_P6|IF_FPU},
    /*  233 */ {I_FCMOVU, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1864, IF_P6|IF_FPU},
    /*  234 */ {I_FCMOVU, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1869, IF_P6|IF_FPU},
    /*  235 */ {I_FCOM, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3189, IF_8086|IF_FPU},
    /*  236 */ {I_FCOM, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3193, IF_8086|IF_FPU},
    /*  237 */ {I_FCOM, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1874, IF_8086|IF_FPU},
    /*  238 */ {I_FCOM, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1879, IF_8086|IF_FPU},
    /*  239 */ {I_FCOMI, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1884, IF_P6|IF_FPU},
    /*  240 */ {I_FCOMI, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1889, IF_P6|IF_FPU},
    /*  241 */ {I_FCOMIP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1894, IF_P6|IF_FPU},
    /*  242 */ {I_FCOMIP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1899, IF_P6|IF_FPU},
    /*  243 */ {I_FCOMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3209, IF_8086|IF_FPU},
    /*  244 */ {I_FCOMP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3213, IF_8086|IF_FPU},
    /*  245 */ {I_FCOMP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1904, IF_8086|IF_FPU},
    /*  246 */ {I_FCOMP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1909, IF_8086|IF_FPU},
    /*  247 */ {I_FCOMPP, 0, {0,0,0,0,0}, nasm_bytecodes+3221, IF_8086|IF_FPU},
    /*  248 */ {I_FCOS, 0, {0,0,0,0,0}, nasm_bytecodes+3225, IF_386|IF_FPU},
    /*  249 */ {I_FDECSTP, 0, {0,0,0,0,0}, nasm_bytecodes+3229, IF_8086|IF_FPU},
    /*  250 */ {I_FDISI, 0, {0,0,0,0,0}, nasm_bytecodes+1914, IF_8086|IF_FPU},
    /*  251 */ {I_FDIV, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3233, IF_8086|IF_FPU},
    /*  252 */ {I_FDIV, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3237, IF_8086|IF_FPU},
    /*  253 */ {I_FDIV, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+1919, IF_8086|IF_FPU},
    /*  254 */ {I_FDIV, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1924, IF_8086|IF_FPU},
    /*  255 */ {I_FDIV, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1919, IF_8086|IF_FPU},
    /*  256 */ {I_FDIV, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1929, IF_8086|IF_FPU},
    /*  257 */ {I_FDIVP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1934, IF_8086|IF_FPU},
    /*  258 */ {I_FDIVP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1934, IF_8086|IF_FPU},
    /*  259 */ {I_FDIVR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3245, IF_8086|IF_FPU},
    /*  260 */ {I_FDIVR, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3249, IF_8086|IF_FPU},
    /*  261 */ {I_FDIVR, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+1939, IF_8086|IF_FPU},
    /*  262 */ {I_FDIVR, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1939, IF_8086|IF_FPU},
    /*  263 */ {I_FDIVR, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1944, IF_8086|IF_FPU},
    /*  264 */ {I_FDIVR, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1949, IF_8086|IF_FPU},
    /*  265 */ {I_FDIVRP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1954, IF_8086|IF_FPU},
    /*  266 */ {I_FDIVRP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1954, IF_8086|IF_FPU},
    /*  267 */ {I_FEMMS, 0, {0,0,0,0,0}, nasm_bytecodes+3257, IF_PENT|IF_3DNOW},
    /*  268 */ {I_FENI, 0, {0,0,0,0,0}, nasm_bytecodes+1959, IF_8086|IF_FPU},
    /*  269 */ {I_FFREE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1964, IF_8086|IF_FPU},
    /*  270 */ {I_FFREE, 0, {0,0,0,0,0}, nasm_bytecodes+3261, IF_8086|IF_FPU},
    /*  271 */ {I_FFREEP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1969, IF_286|IF_FPU|IF_UNDOC},
    /*  272 */ {I_FFREEP, 0, {0,0,0,0,0}, nasm_bytecodes+3265, IF_286|IF_FPU|IF_UNDOC},
    /*  273 */ {I_FIADD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3269, IF_8086|IF_FPU},
    /*  274 */ {I_FIADD, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3273, IF_8086|IF_FPU},
    /*  275 */ {I_FICOM, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3277, IF_8086|IF_FPU},
    /*  276 */ {I_FICOM, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3281, IF_8086|IF_FPU},
    /*  277 */ {I_FICOMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3285, IF_8086|IF_FPU},
    /*  278 */ {I_FICOMP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3289, IF_8086|IF_FPU},
    /*  279 */ {I_FIDIV, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3293, IF_8086|IF_FPU},
    /*  280 */ {I_FIDIV, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3297, IF_8086|IF_FPU},
    /*  281 */ {I_FIDIVR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3301, IF_8086|IF_FPU},
    /*  282 */ {I_FIDIVR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3305, IF_8086|IF_FPU},
    /*  283 */ {I_FILD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3309, IF_8086|IF_FPU},
    /*  284 */ {I_FILD, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3313, IF_8086|IF_FPU},
    /*  285 */ {I_FILD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3317, IF_8086|IF_FPU},
    /*  286 */ {I_FIMUL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3321, IF_8086|IF_FPU},
    /*  287 */ {I_FIMUL, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3325, IF_8086|IF_FPU},
    /*  288 */ {I_FINCSTP, 0, {0,0,0,0,0}, nasm_bytecodes+3329, IF_8086|IF_FPU},
    /*  289 */ {I_FINIT, 0, {0,0,0,0,0}, nasm_bytecodes+1974, IF_8086|IF_FPU},
    /*  290 */ {I_FIST, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3333, IF_8086|IF_FPU},
    /*  291 */ {I_FIST, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3337, IF_8086|IF_FPU},
    /*  292 */ {I_FISTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3341, IF_8086|IF_FPU},
    /*  293 */ {I_FISTP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3345, IF_8086|IF_FPU},
    /*  294 */ {I_FISTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3349, IF_8086|IF_FPU},
    /*  295 */ {I_FISUB, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3353, IF_8086|IF_FPU},
    /*  296 */ {I_FISUB, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3357, IF_8086|IF_FPU},
    /*  297 */ {I_FISUBR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3361, IF_8086|IF_FPU},
    /*  298 */ {I_FISUBR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+3365, IF_8086|IF_FPU},
    /*  299 */ {I_FLD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3369, IF_8086|IF_FPU},
    /*  300 */ {I_FLD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3373, IF_8086|IF_FPU},
    /*  301 */ {I_FLD, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+3377, IF_8086|IF_FPU},
    /*  302 */ {I_FLD, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1979, IF_8086|IF_FPU},
    /*  303 */ {I_FLD1, 0, {0,0,0,0,0}, nasm_bytecodes+3385, IF_8086|IF_FPU},
    /*  304 */ {I_FLDCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+3389, IF_8086|IF_FPU|IF_SW},
    /*  305 */ {I_FLDENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+3393, IF_8086|IF_FPU},
    /*  306 */ {I_FLDL2E, 0, {0,0,0,0,0}, nasm_bytecodes+3397, IF_8086|IF_FPU},
    /*  307 */ {I_FLDL2T, 0, {0,0,0,0,0}, nasm_bytecodes+3401, IF_8086|IF_FPU},
    /*  308 */ {I_FLDLG2, 0, {0,0,0,0,0}, nasm_bytecodes+3405, IF_8086|IF_FPU},
    /*  309 */ {I_FLDLN2, 0, {0,0,0,0,0}, nasm_bytecodes+3409, IF_8086|IF_FPU},
    /*  310 */ {I_FLDPI, 0, {0,0,0,0,0}, nasm_bytecodes+3413, IF_8086|IF_FPU},
    /*  311 */ {I_FLDZ, 0, {0,0,0,0,0}, nasm_bytecodes+3417, IF_8086|IF_FPU},
    /*  312 */ {I_FMUL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3421, IF_8086|IF_FPU},
    /*  313 */ {I_FMUL, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3425, IF_8086|IF_FPU},
    /*  314 */ {I_FMUL, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+1984, IF_8086|IF_FPU},
    /*  315 */ {I_FMUL, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1984, IF_8086|IF_FPU},
    /*  316 */ {I_FMUL, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1989, IF_8086|IF_FPU},
    /*  317 */ {I_FMUL, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+1994, IF_8086|IF_FPU},
    /*  318 */ {I_FMULP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+1999, IF_8086|IF_FPU},
    /*  319 */ {I_FMULP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+1999, IF_8086|IF_FPU},
    /*  320 */ {I_FNCLEX, 0, {0,0,0,0,0}, nasm_bytecodes+1790, IF_8086|IF_FPU},
    /*  321 */ {I_FNDISI, 0, {0,0,0,0,0}, nasm_bytecodes+1915, IF_8086|IF_FPU},
    /*  322 */ {I_FNENI, 0, {0,0,0,0,0}, nasm_bytecodes+1960, IF_8086|IF_FPU},
    /*  323 */ {I_FNINIT, 0, {0,0,0,0,0}, nasm_bytecodes+1975, IF_8086|IF_FPU},
    /*  324 */ {I_FNOP, 0, {0,0,0,0,0}, nasm_bytecodes+3433, IF_8086|IF_FPU},
    /*  325 */ {I_FNSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2005, IF_8086|IF_FPU},
    /*  326 */ {I_FNSTCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2015, IF_8086|IF_FPU|IF_SW},
    /*  327 */ {I_FNSTENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2020, IF_8086|IF_FPU},
    /*  328 */ {I_FNSTSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2030, IF_8086|IF_FPU|IF_SW},
    /*  329 */ {I_FNSTSW, 1, {REG_AX,0,0,0,0}, nasm_bytecodes+2035, IF_286|IF_FPU},
    /*  330 */ {I_FPATAN, 0, {0,0,0,0,0}, nasm_bytecodes+3437, IF_8086|IF_FPU},
    /*  331 */ {I_FPREM, 0, {0,0,0,0,0}, nasm_bytecodes+3441, IF_8086|IF_FPU},
    /*  332 */ {I_FPREM1, 0, {0,0,0,0,0}, nasm_bytecodes+3445, IF_386|IF_FPU},
    /*  333 */ {I_FPTAN, 0, {0,0,0,0,0}, nasm_bytecodes+3449, IF_8086|IF_FPU},
    /*  334 */ {I_FRNDINT, 0, {0,0,0,0,0}, nasm_bytecodes+3453, IF_8086|IF_FPU},
    /*  335 */ {I_FRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+3457, IF_8086|IF_FPU},
    /*  336 */ {I_FSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2004, IF_8086|IF_FPU},
    /*  337 */ {I_FSCALE, 0, {0,0,0,0,0}, nasm_bytecodes+3461, IF_8086|IF_FPU},
    /*  338 */ {I_FSETPM, 0, {0,0,0,0,0}, nasm_bytecodes+3465, IF_286|IF_FPU},
    /*  339 */ {I_FSIN, 0, {0,0,0,0,0}, nasm_bytecodes+3469, IF_386|IF_FPU},
    /*  340 */ {I_FSINCOS, 0, {0,0,0,0,0}, nasm_bytecodes+3473, IF_386|IF_FPU},
    /*  341 */ {I_FSQRT, 0, {0,0,0,0,0}, nasm_bytecodes+3477, IF_8086|IF_FPU},
    /*  342 */ {I_FST, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3481, IF_8086|IF_FPU},
    /*  343 */ {I_FST, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3485, IF_8086|IF_FPU},
    /*  344 */ {I_FST, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2009, IF_8086|IF_FPU},
    /*  345 */ {I_FSTCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2014, IF_8086|IF_FPU|IF_SW},
    /*  346 */ {I_FSTENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2019, IF_8086|IF_FPU},
    /*  347 */ {I_FSTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3493, IF_8086|IF_FPU},
    /*  348 */ {I_FSTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3497, IF_8086|IF_FPU},
    /*  349 */ {I_FSTP, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+3501, IF_8086|IF_FPU},
    /*  350 */ {I_FSTP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2024, IF_8086|IF_FPU},
    /*  351 */ {I_FSTSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2029, IF_8086|IF_FPU|IF_SW},
    /*  352 */ {I_FSTSW, 1, {REG_AX,0,0,0,0}, nasm_bytecodes+2034, IF_286|IF_FPU},
    /*  353 */ {I_FSUB, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3509, IF_8086|IF_FPU},
    /*  354 */ {I_FSUB, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3513, IF_8086|IF_FPU},
    /*  355 */ {I_FSUB, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+2039, IF_8086|IF_FPU},
    /*  356 */ {I_FSUB, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+2039, IF_8086|IF_FPU},
    /*  357 */ {I_FSUB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2044, IF_8086|IF_FPU},
    /*  358 */ {I_FSUB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2049, IF_8086|IF_FPU},
    /*  359 */ {I_FSUBP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2054, IF_8086|IF_FPU},
    /*  360 */ {I_FSUBP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+2054, IF_8086|IF_FPU},
    /*  361 */ {I_FSUBR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+3521, IF_8086|IF_FPU},
    /*  362 */ {I_FSUBR, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+3525, IF_8086|IF_FPU},
    /*  363 */ {I_FSUBR, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+2059, IF_8086|IF_FPU},
    /*  364 */ {I_FSUBR, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+2059, IF_8086|IF_FPU},
    /*  365 */ {I_FSUBR, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2064, IF_8086|IF_FPU},
    /*  366 */ {I_FSUBR, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2069, IF_8086|IF_FPU},
    /*  367 */ {I_FSUBRP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2074, IF_8086|IF_FPU},
    /*  368 */ {I_FSUBRP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+2074, IF_8086|IF_FPU},
    /*  369 */ {I_FTST, 0, {0,0,0,0,0}, nasm_bytecodes+3533, IF_8086|IF_FPU},
    /*  370 */ {I_FUCOM, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2079, IF_386|IF_FPU},
    /*  371 */ {I_FUCOM, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2084, IF_386|IF_FPU},
    /*  372 */ {I_FUCOMI, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2089, IF_P6|IF_FPU},
    /*  373 */ {I_FUCOMI, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2094, IF_P6|IF_FPU},
    /*  374 */ {I_FUCOMIP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2099, IF_P6|IF_FPU},
    /*  375 */ {I_FUCOMIP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2104, IF_P6|IF_FPU},
    /*  376 */ {I_FUCOMP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2109, IF_386|IF_FPU},
    /*  377 */ {I_FUCOMP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2114, IF_386|IF_FPU},
    /*  378 */ {I_FUCOMPP, 0, {0,0,0,0,0}, nasm_bytecodes+3553, IF_386|IF_FPU},
    /*  379 */ {I_FXAM, 0, {0,0,0,0,0}, nasm_bytecodes+3557, IF_8086|IF_FPU},
    /*  380 */ {I_FXCH, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+2119, IF_8086|IF_FPU},
    /*  381 */ {I_FXCH, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+2119, IF_8086|IF_FPU},
    /*  382 */ {I_FXCH, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+2124, IF_8086|IF_FPU},
    /*  383 */ {I_FXTRACT, 0, {0,0,0,0,0}, nasm_bytecodes+3565, IF_8086|IF_FPU},
    /*  384 */ {I_FYL2X, 0, {0,0,0,0,0}, nasm_bytecodes+3569, IF_8086|IF_FPU},
    /*  385 */ {I_FYL2XP1, 0, {0,0,0,0,0}, nasm_bytecodes+3573, IF_8086|IF_FPU},
    /*  386 */ {I_HLT, 0, {0,0,0,0,0}, nasm_bytecodes+4033, IF_8086|IF_PRIV},
    /*  387 */ {I_IDIV, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3577, IF_8086},
    /*  388 */ {I_IDIV, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2129, IF_8086},
    /*  389 */ {I_IDIV, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2134, IF_386},
    /*  390 */ {I_IMUL, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3581, IF_8086},
    /*  391 */ {I_IMUL, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2139, IF_8086},
    /*  392 */ {I_IMUL, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2144, IF_386},
    /*  393 */ {I_IMUL, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+918, IF_386|IF_SM},
    /*  394 */ {I_IMUL, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+918, IF_386},
    /*  395 */ {I_IMUL, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+924, IF_386|IF_SM},
    /*  396 */ {I_IMUL, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+924, IF_386},
    /*  397 */ {I_IMUL, 3, {REG_GPR|BITS16,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+930, IF_186|IF_SM},
    /*  398 */ {I_IMUL, 3, {REG_GPR|BITS16,MEMORY,IMMEDIATE|BITS16,0,0}, nasm_bytecodes+936, IF_186|IF_SM},
    /*  399 */ {I_IMUL, 3, {REG_GPR|BITS16,REG_GPR|BITS16,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+930, IF_186},
    /*  400 */ {I_IMUL, 3, {REG_GPR|BITS16,REG_GPR|BITS16,IMMEDIATE|BITS16,0,0}, nasm_bytecodes+936, IF_186},
    /*  401 */ {I_IMUL, 3, {REG_GPR|BITS32,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+948, IF_386|IF_SM},
    /*  402 */ {I_IMUL, 3, {REG_GPR|BITS32,MEMORY,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+954, IF_386|IF_SM},
    /*  403 */ {I_IMUL, 3, {REG_GPR|BITS32,REG_GPR|BITS32,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+948, IF_386},
    /*  404 */ {I_IMUL, 3, {REG_GPR|BITS32,REG_GPR|BITS32,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+954, IF_386},
    /*  405 */ {I_IMUL, 2, {REG_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+966, IF_186},
    /*  406 */ {I_IMUL, 2, {REG_GPR|BITS16,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+972, IF_186},
    /*  407 */ {I_IMUL, 2, {REG_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+984, IF_386},
    /*  408 */ {I_IMUL, 2, {REG_GPR|BITS32,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+990, IF_386},
    /*  409 */ {I_IN, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3585, IF_8086|IF_SB},
    /*  410 */ {I_IN, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+2149, IF_8086|IF_SB},
    /*  411 */ {I_IN, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+2154, IF_386|IF_SB},
    /*  412 */ {I_IN, 2, {REG_AL,REG_DX,0,0,0}, nasm_bytecodes+4039, IF_8086},
    /*  413 */ {I_IN, 2, {REG_AX,REG_DX,0,0,0}, nasm_bytecodes+3589, IF_8086},
    /*  414 */ {I_IN, 2, {REG_EAX,REG_DX,0,0,0}, nasm_bytecodes+3593, IF_386},
    /*  415 */ {I_INC, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+3597, IF_8086|IF_NOLONG},
    /*  416 */ {I_INC, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+3601, IF_386|IF_NOLONG},
    /*  417 */ {I_INC, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3605, IF_8086},
    /*  418 */ {I_INC, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2159, IF_8086},
    /*  419 */ {I_INC, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2164, IF_386},
    /*  420 */ {I_INSB, 0, {0,0,0,0,0}, nasm_bytecodes+4042, IF_186},
    /*  421 */ {I_INSD, 0, {0,0,0,0,0}, nasm_bytecodes+3609, IF_386},
    /*  422 */ {I_INSW, 0, {0,0,0,0,0}, nasm_bytecodes+3613, IF_186},
    /*  423 */ {I_INT, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+3617, IF_8086|IF_SB},
    /*  424 */ {I_INT1, 0, {0,0,0,0,0}, nasm_bytecodes+4036, IF_386},
    /*  425 */ {I_INT3, 0, {0,0,0,0,0}, nasm_bytecodes+4045, IF_8086},
    /*  426 */ {I_INTO, 0, {0,0,0,0,0}, nasm_bytecodes+4048, IF_8086|IF_NOLONG},
    /*  427 */ {I_INVD, 0, {0,0,0,0,0}, nasm_bytecodes+3621, IF_486|IF_PRIV},
    /*  428 */ {I_INVLPG, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2169, IF_486|IF_PRIV},
    /*  429 */ {I_IRET, 0, {0,0,0,0,0}, nasm_bytecodes+3625, IF_8086},
    /*  430 */ {I_IRETD, 0, {0,0,0,0,0}, nasm_bytecodes+3629, IF_386},
    /*  431 */ {I_IRETW, 0, {0,0,0,0,0}, nasm_bytecodes+3633, IF_8086},
    /*  432 */ {I_JCXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2174, IF_8086|IF_NOLONG},
    /*  433 */ {I_JECXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2179, IF_386},
    /*  434 */ {I_JMP, 1, {IMMEDIATE|SHORT,0,0,0,0}, nasm_bytecodes+2185, IF_8086},
    /*  435 */ {I_JMP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2189, IF_8086},
    /*  436 */ {I_JMP, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+2194, IF_8086},
    /*  437 */ {I_JMP, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+2199, IF_386},
    /*  438 */ {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+1020, IF_8086|IF_NOLONG},
    /*  439 */ {I_JMP, 2, {IMMEDIATE|BITS16|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+1026, IF_8086|IF_NOLONG},
    /*  440 */ {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1026, IF_8086|IF_NOLONG},
    /*  441 */ {I_JMP, 2, {IMMEDIATE|BITS32|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+1032, IF_386|IF_NOLONG},
    /*  442 */ {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1032, IF_386|IF_NOLONG},
    /*  443 */ {I_JMP, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+2204, IF_8086|IF_NOLONG},
    /*  444 */ {I_JMP, 1, {MEMORY|BITS16|FAR,0,0,0,0}, nasm_bytecodes+2209, IF_8086},
    /*  445 */ {I_JMP, 1, {MEMORY|BITS32|FAR,0,0,0,0}, nasm_bytecodes+2214, IF_386},
    /*  446 */ {I_JMP, 1, {MEMORY|NEAR,0,0,0,0}, nasm_bytecodes+2219, IF_8086},
    /*  447 */ {I_JMP, 1, {MEMORY|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+2224, IF_8086},
    /*  448 */ {I_JMP, 1, {MEMORY|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+2229, IF_386|IF_NOLONG},
    /*  449 */ {I_JMP, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2224, IF_8086},
    /*  450 */ {I_JMP, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2229, IF_386|IF_NOLONG},
    /*  451 */ {I_JMP, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2219, IF_8086},
    /*  452 */ {I_JMP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+2224, IF_8086},
    /*  453 */ {I_JMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+2229, IF_386|IF_NOLONG},
    /*  454 */ {I_LAHF, 0, {0,0,0,0,0}, nasm_bytecodes+4051, IF_8086},
    /*  455 */ {I_LAR, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1038, IF_286|IF_PROT|IF_SW},
    /*  456 */ {I_LAR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1038, IF_286|IF_PROT},
    /*  457 */ {I_LAR, 2, {REG_GPR|BITS16,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1038, IF_386|IF_PROT},
    /*  458 */ {I_LAR, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1044, IF_386|IF_PROT|IF_SW},
    /*  459 */ {I_LAR, 2, {REG_GPR|BITS32,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1044, IF_386|IF_PROT},
    /*  460 */ {I_LAR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1044, IF_386|IF_PROT},
    /*  461 */ {I_LDS, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2234, IF_8086|IF_NOLONG},
    /*  462 */ {I_LDS, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2239, IF_386|IF_NOLONG},
    /*  463 */ {I_LEA, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2244, IF_8086},
    /*  464 */ {I_LEA, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2249, IF_386},
    /*  465 */ {I_LEAVE, 0, {0,0,0,0,0}, nasm_bytecodes+4054, IF_186},
    /*  466 */ {I_LES, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2254, IF_8086|IF_NOLONG},
    /*  467 */ {I_LES, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2259, IF_386|IF_NOLONG},
    /*  468 */ {I_LFS, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1050, IF_386},
    /*  469 */ {I_LFS, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1056, IF_386},
    /*  470 */ {I_LGDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2264, IF_286|IF_PRIV},
    /*  471 */ {I_LGS, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1062, IF_386},
    /*  472 */ {I_LGS, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1068, IF_386},
    /*  473 */ {I_LIDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2269, IF_286|IF_PRIV},
    /*  474 */ {I_LLDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2274, IF_286|IF_PROT|IF_PRIV},
    /*  475 */ {I_LLDT, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+2274, IF_286|IF_PROT|IF_PRIV},
    /*  476 */ {I_LLDT, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2274, IF_286|IF_PROT|IF_PRIV},
    /*  477 */ {I_LMSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2279, IF_286|IF_PRIV},
    /*  478 */ {I_LMSW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+2279, IF_286|IF_PRIV},
    /*  479 */ {I_LMSW, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2279, IF_286|IF_PRIV},
    /*  480 */ {I_LOADALL, 0, {0,0,0,0,0}, nasm_bytecodes+3637, IF_386|IF_UNDOC},
    /*  481 */ {I_LOADALL286, 0, {0,0,0,0,0}, nasm_bytecodes+3641, IF_286|IF_UNDOC},
    /*  482 */ {I_LODSB, 0, {0,0,0,0,0}, nasm_bytecodes+4057, IF_8086},
    /*  483 */ {I_LODSD, 0, {0,0,0,0,0}, nasm_bytecodes+3645, IF_386},
    /*  484 */ {I_LODSW, 0, {0,0,0,0,0}, nasm_bytecodes+3649, IF_8086},
    /*  485 */ {I_LOOP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2284, IF_8086},
    /*  486 */ {I_LOOP, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+2289, IF_8086|IF_NOLONG},
    /*  487 */ {I_LOOP, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+2294, IF_386},
    /*  488 */ {I_LOOPE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2299, IF_8086},
    /*  489 */ {I_LOOPE, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+2304, IF_8086|IF_NOLONG},
    /*  490 */ {I_LOOPE, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+2309, IF_386},
    /*  491 */ {I_LOOPNE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2314, IF_8086},
    /*  492 */ {I_LOOPNE, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+2319, IF_8086|IF_NOLONG},
    /*  493 */ {I_LOOPNE, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+2324, IF_386},
    /*  494 */ {I_LOOPNZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2314, IF_8086},
    /*  495 */ {I_LOOPNZ, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+2319, IF_8086|IF_NOLONG},
    /*  496 */ {I_LOOPNZ, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+2324, IF_386},
    /*  497 */ {I_LOOPZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2299, IF_8086},
    /*  498 */ {I_LOOPZ, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+2304, IF_8086|IF_NOLONG},
    /*  499 */ {I_LOOPZ, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+2309, IF_386},
    /*  500 */ {I_LSL, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1074, IF_286|IF_PROT|IF_SW},
    /*  501 */ {I_LSL, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1074, IF_286|IF_PROT},
    /*  502 */ {I_LSL, 2, {REG_GPR|BITS16,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1074, IF_386|IF_PROT},
    /*  503 */ {I_LSL, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1080, IF_386|IF_PROT|IF_SW},
    /*  504 */ {I_LSL, 2, {REG_GPR|BITS32,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1080, IF_386|IF_PROT},
    /*  505 */ {I_LSL, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1080, IF_386|IF_PROT},
    /*  506 */ {I_LSS, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1086, IF_386},
    /*  507 */ {I_LSS, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+1092, IF_386},
    /*  508 */ {I_LTR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2329, IF_286|IF_PROT|IF_PRIV},
    /*  509 */ {I_LTR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+2329, IF_286|IF_PROT|IF_PRIV},
    /*  510 */ {I_LTR, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2329, IF_286|IF_PROT|IF_PRIV},
    /*  511 */ {I_MOV, 2, {MEMORY,REG_SREG,0,0,0}, nasm_bytecodes+2340, IF_8086|IF_SW},
    /*  512 */ {I_MOV, 2, {REG_GPR|BITS16,REG_SREG,0,0,0}, nasm_bytecodes+2334, IF_8086},
    /*  513 */ {I_MOV, 2, {REG_GPR|BITS32,REG_SREG,0,0,0}, nasm_bytecodes+2339, IF_386},
    /*  514 */ {I_MOV, 2, {REG_SREG,MEMORY,0,0,0}, nasm_bytecodes+2350, IF_8086|IF_SW},
    /*  515 */ {I_MOV, 2, {REG_SREG,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2344, IF_8086},
    /*  516 */ {I_MOV, 2, {REG_SREG,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2349, IF_386},
    /*  517 */ {I_MOV, 2, {REG_AL,MEM_OFFS,0,0,0}, nasm_bytecodes+3653, IF_8086|IF_SM},
    /*  518 */ {I_MOV, 2, {REG_AX,MEM_OFFS,0,0,0}, nasm_bytecodes+2354, IF_8086|IF_SM},
    /*  519 */ {I_MOV, 2, {REG_EAX,MEM_OFFS,0,0,0}, nasm_bytecodes+2359, IF_386|IF_SM},
    /*  520 */ {I_MOV, 2, {MEM_OFFS,REG_AL,0,0,0}, nasm_bytecodes+3657, IF_8086|IF_SM},
    /*  521 */ {I_MOV, 2, {MEM_OFFS,REG_AX,0,0,0}, nasm_bytecodes+2364, IF_8086|IF_SM},
    /*  522 */ {I_MOV, 2, {MEM_OFFS,REG_EAX,0,0,0}, nasm_bytecodes+2369, IF_386|IF_SM},
    /*  523 */ {I_MOV, 2, {REG_GPR|BITS32,REG_CREG,0,0,0}, nasm_bytecodes+1098, IF_386|IF_PRIV|IF_NOLONG},
    /*  524 */ {I_MOV, 2, {REG_CREG,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1104, IF_386|IF_PRIV|IF_NOLONG},
    /*  525 */ {I_MOV, 2, {REG_GPR|BITS32,REG_DREG,0,0,0}, nasm_bytecodes+2374, IF_386|IF_PRIV|IF_NOLONG},
    /*  526 */ {I_MOV, 2, {REG_DREG,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2379, IF_386|IF_PRIV|IF_NOLONG},
    /*  527 */ {I_MOV, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3661, IF_8086|IF_SM},
    /*  528 */ {I_MOV, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3661, IF_8086},
    /*  529 */ {I_MOV, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2394, IF_8086|IF_SM},
    /*  530 */ {I_MOV, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2394, IF_8086},
    /*  531 */ {I_MOV, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2399, IF_386|IF_SM},
    /*  532 */ {I_MOV, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2399, IF_386},
    /*  533 */ {I_MOV, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3665, IF_8086|IF_SM},
    /*  534 */ {I_MOV, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3665, IF_8086},
    /*  535 */ {I_MOV, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2404, IF_8086|IF_SM},
    /*  536 */ {I_MOV, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2404, IF_8086},
    /*  537 */ {I_MOV, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2409, IF_386|IF_SM},
    /*  538 */ {I_MOV, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2409, IF_386},
    /*  539 */ {I_MOV, 2, {REG_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+3669, IF_8086|IF_SM},
    /*  540 */ {I_MOV, 2, {REG_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+2414, IF_8086|IF_SM},
    /*  541 */ {I_MOV, 2, {REG_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+2419, IF_386|IF_SM},
    /*  542 */ {I_MOV, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2424, IF_8086|IF_SM},
    /*  543 */ {I_MOV, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1110, IF_8086|IF_SM},
    /*  544 */ {I_MOV, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1116, IF_386|IF_SM},
    /*  545 */ {I_MOV, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+2424, IF_8086|IF_SM},
    /*  546 */ {I_MOV, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1110, IF_8086|IF_SM},
    /*  547 */ {I_MOV, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1116, IF_386|IF_SM},
    /*  548 */ {I_MOVD, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+1122, IF_PENT|IF_MMX|IF_SD},
    /*  549 */ {I_MOVD, 2, {MMXREG,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1122, IF_PENT|IF_MMX},
    /*  550 */ {I_MOVD, 2, {MEMORY,MMXREG,0,0,0}, nasm_bytecodes+1128, IF_PENT|IF_MMX|IF_SD},
    /*  551 */ {I_MOVD, 2, {REG_GPR|BITS32,MMXREG,0,0,0}, nasm_bytecodes+1128, IF_PENT|IF_MMX},
    /*  552 */ {I_MOVQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+208, IF_PENT|IF_MMX|IF_SQ},
    /*  553 */ {I_MOVQ, 2, {RM_MMX,MMXREG,0,0,0}, nasm_bytecodes+215, IF_PENT|IF_MMX|IF_SQ},
    /*  554 */ {I_MOVSB, 0, {0,0,0,0,0}, nasm_bytecodes+61, IF_8086},
    /*  555 */ {I_MOVSD, 0, {0,0,0,0,0}, nasm_bytecodes+3673, IF_386},
    /*  556 */ {I_MOVSW, 0, {0,0,0,0,0}, nasm_bytecodes+3677, IF_8086},
    /*  557 */ {I_MOVSX, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1134, IF_386|IF_SB},
    /*  558 */ {I_MOVSX, 2, {REG_GPR|BITS16,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+1134, IF_386},
    /*  559 */ {I_MOVSX, 2, {REG_GPR|BITS32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+1140, IF_386},
    /*  560 */ {I_MOVSX, 2, {REG_GPR|BITS32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+1146, IF_386},
    /*  561 */ {I_MOVZX, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+1152, IF_386|IF_SB},
    /*  562 */ {I_MOVZX, 2, {REG_GPR|BITS16,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+1152, IF_386},
    /*  563 */ {I_MOVZX, 2, {REG_GPR|BITS32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+1158, IF_386},
    /*  564 */ {I_MOVZX, 2, {REG_GPR|BITS32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+1164, IF_386},
    /*  565 */ {I_MUL, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3681, IF_8086},
    /*  566 */ {I_MUL, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2429, IF_8086},
    /*  567 */ {I_MUL, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2434, IF_386},
    /*  568 */ {I_NEG, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3685, IF_8086},
    /*  569 */ {I_NEG, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2439, IF_8086},
    /*  570 */ {I_NEG, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2444, IF_386},
    /*  571 */ {I_NOP, 0, {0,0,0,0,0}, nasm_bytecodes+3689, IF_8086},
    /*  572 */ {I_NOP, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1170, IF_P6},
    /*  573 */ {I_NOP, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1176, IF_P6},
    /*  574 */ {I_NOT, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+3693, IF_8086},
    /*  575 */ {I_NOT, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2449, IF_8086},
    /*  576 */ {I_NOT, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2454, IF_386},
    /*  577 */ {I_OR, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3697, IF_8086|IF_SM},
    /*  578 */ {I_OR, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3697, IF_8086},
    /*  579 */ {I_OR, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2459, IF_8086|IF_SM},
    /*  580 */ {I_OR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2459, IF_8086},
    /*  581 */ {I_OR, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2464, IF_386|IF_SM},
    /*  582 */ {I_OR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2464, IF_386},
    /*  583 */ {I_OR, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3701, IF_8086|IF_SM},
    /*  584 */ {I_OR, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3701, IF_8086},
    /*  585 */ {I_OR, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2469, IF_8086|IF_SM},
    /*  586 */ {I_OR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2469, IF_8086},
    /*  587 */ {I_OR, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2474, IF_386|IF_SM},
    /*  588 */ {I_OR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2474, IF_386},
    /*  589 */ {I_OR, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1182, IF_8086},
    /*  590 */ {I_OR, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1188, IF_386},
    /*  591 */ {I_OR, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3705, IF_8086|IF_SM},
    /*  592 */ {I_OR, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+1182, IF_8086|IF_SM},
    /*  593 */ {I_OR, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+2479, IF_8086|IF_SM},
    /*  594 */ {I_OR, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+1188, IF_386|IF_SM},
    /*  595 */ {I_OR, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+2484, IF_386|IF_SM},
    /*  596 */ {I_OR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2489, IF_8086|IF_SM},
    /*  597 */ {I_OR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1194, IF_8086|IF_SM},
    /*  598 */ {I_OR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1200, IF_386|IF_SM},
    /*  599 */ {I_OR, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+2489, IF_8086|IF_SM},
    /*  600 */ {I_OR, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1194, IF_8086|IF_SM},
    /*  601 */ {I_OR, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1200, IF_386|IF_SM},
    /*  602 */ {I_OUT, 2, {IMMEDIATE,REG_AL,0,0,0}, nasm_bytecodes+3709, IF_8086|IF_SB},
    /*  603 */ {I_OUT, 2, {IMMEDIATE,REG_AX,0,0,0}, nasm_bytecodes+2494, IF_8086|IF_SB},
    /*  604 */ {I_OUT, 2, {IMMEDIATE,REG_EAX,0,0,0}, nasm_bytecodes+2499, IF_386|IF_SB},
    /*  605 */ {I_OUT, 2, {REG_DX,REG_AL,0,0,0}, nasm_bytecodes+4060, IF_8086},
    /*  606 */ {I_OUT, 2, {REG_DX,REG_AX,0,0,0}, nasm_bytecodes+3713, IF_8086},
    /*  607 */ {I_OUT, 2, {REG_DX,REG_EAX,0,0,0}, nasm_bytecodes+3717, IF_386},
    /*  608 */ {I_OUTSB, 0, {0,0,0,0,0}, nasm_bytecodes+4063, IF_186},
    /*  609 */ {I_OUTSD, 0, {0,0,0,0,0}, nasm_bytecodes+3721, IF_386},
    /*  610 */ {I_OUTSW, 0, {0,0,0,0,0}, nasm_bytecodes+3725, IF_186},
    /*  611 */ {I_PACKSSDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+222, IF_PENT|IF_MMX|IF_SQ},
    /*  612 */ {I_PACKSSWB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+229, IF_PENT|IF_MMX|IF_SQ},
    /*  613 */ {I_PACKUSWB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+236, IF_PENT|IF_MMX|IF_SQ},
    /*  614 */ {I_PADDB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+243, IF_PENT|IF_MMX|IF_SQ},
    /*  615 */ {I_PADDD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+250, IF_PENT|IF_MMX|IF_SQ},
    /*  616 */ {I_PADDSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+257, IF_PENT|IF_MMX|IF_SQ},
    /*  617 */ {I_PADDSIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+1206, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  618 */ {I_PADDSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+264, IF_PENT|IF_MMX|IF_SQ},
    /*  619 */ {I_PADDUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+271, IF_PENT|IF_MMX|IF_SQ},
    /*  620 */ {I_PADDUSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+278, IF_PENT|IF_MMX|IF_SQ},
    /*  621 */ {I_PADDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+285, IF_PENT|IF_MMX|IF_SQ},
    /*  622 */ {I_PAND, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+292, IF_PENT|IF_MMX|IF_SQ},
    /*  623 */ {I_PANDN, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+299, IF_PENT|IF_MMX|IF_SQ},
    /*  624 */ {I_PAUSE, 0, {0,0,0,0,0}, nasm_bytecodes+2504, IF_8086},
    /*  625 */ {I_PAVEB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+1212, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  626 */ {I_PAVGUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+0, IF_PENT|IF_3DNOW|IF_SQ},
    /*  627 */ {I_PCMPEQB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+306, IF_PENT|IF_MMX|IF_SQ},
    /*  628 */ {I_PCMPEQD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+313, IF_PENT|IF_MMX|IF_SQ},
    /*  629 */ {I_PCMPEQW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+320, IF_PENT|IF_MMX|IF_SQ},
    /*  630 */ {I_PCMPGTB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+327, IF_PENT|IF_MMX|IF_SQ},
    /*  631 */ {I_PCMPGTD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+334, IF_PENT|IF_MMX|IF_SQ},
    /*  632 */ {I_PCMPGTW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+341, IF_PENT|IF_MMX|IF_SQ},
    /*  633 */ {I_PDISTIB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+2509, IF_PENT|IF_MMX|IF_SM|IF_CYRIX},
    /*  634 */ {I_PF2ID, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8, IF_PENT|IF_3DNOW|IF_SQ},
    /*  635 */ {I_PFACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+16, IF_PENT|IF_3DNOW|IF_SQ},
    /*  636 */ {I_PFADD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+24, IF_PENT|IF_3DNOW|IF_SQ},
    /*  637 */ {I_PFCMPEQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+32, IF_PENT|IF_3DNOW|IF_SQ},
    /*  638 */ {I_PFCMPGE, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+40, IF_PENT|IF_3DNOW|IF_SQ},
    /*  639 */ {I_PFCMPGT, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+48, IF_PENT|IF_3DNOW|IF_SQ},
    /*  640 */ {I_PFMAX, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+56, IF_PENT|IF_3DNOW|IF_SQ},
    /*  641 */ {I_PFMIN, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+64, IF_PENT|IF_3DNOW|IF_SQ},
    /*  642 */ {I_PFMUL, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+72, IF_PENT|IF_3DNOW|IF_SQ},
    /*  643 */ {I_PFRCP, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+80, IF_PENT|IF_3DNOW|IF_SQ},
    /*  644 */ {I_PFRCPIT1, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+88, IF_PENT|IF_3DNOW|IF_SQ},
    /*  645 */ {I_PFRCPIT2, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+96, IF_PENT|IF_3DNOW|IF_SQ},
    /*  646 */ {I_PFRSQIT1, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+104, IF_PENT|IF_3DNOW|IF_SQ},
    /*  647 */ {I_PFRSQRT, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+112, IF_PENT|IF_3DNOW|IF_SQ},
    /*  648 */ {I_PFSUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+120, IF_PENT|IF_3DNOW|IF_SQ},
    /*  649 */ {I_PFSUBR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+128, IF_PENT|IF_3DNOW|IF_SQ},
    /*  650 */ {I_PI2FD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+136, IF_PENT|IF_3DNOW|IF_SQ},
    /*  651 */ {I_PMACHRIW, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+2514, IF_PENT|IF_MMX|IF_SM|IF_CYRIX},
    /*  652 */ {I_PMADDWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+348, IF_PENT|IF_MMX|IF_SQ},
    /*  653 */ {I_PMAGW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+1218, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  654 */ {I_PMULHRIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+1224, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  655 */ {I_PMULHRWA, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+144, IF_PENT|IF_3DNOW|IF_SQ},
    /*  656 */ {I_PMULHRWC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+1230, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  657 */ {I_PMULHW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+355, IF_PENT|IF_MMX|IF_SQ},
    /*  658 */ {I_PMULLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+362, IF_PENT|IF_MMX|IF_SQ},
    /*  659 */ {I_PMVGEZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+2519, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  660 */ {I_PMVLZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+2524, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  661 */ {I_PMVNZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+2529, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  662 */ {I_PMVZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+2534, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  663 */ {I_POP, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+3729, IF_8086},
    /*  664 */ {I_POP, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+3733, IF_386|IF_NOLONG},
    /*  665 */ {I_POP, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2539, IF_8086},
    /*  666 */ {I_POP, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2544, IF_386|IF_NOLONG},
    /*  667 */ {I_POP, 1, {REG_DESS,0,0,0,0}, nasm_bytecodes+3559, IF_8086|IF_NOLONG},
    /*  668 */ {I_POP, 1, {REG_FSGS,0,0,0,0}, nasm_bytecodes+3737, IF_386},
    /*  669 */ {I_POPA, 0, {0,0,0,0,0}, nasm_bytecodes+3741, IF_186|IF_NOLONG},
    /*  670 */ {I_POPAD, 0, {0,0,0,0,0}, nasm_bytecodes+3745, IF_386|IF_NOLONG},
    /*  671 */ {I_POPAW, 0, {0,0,0,0,0}, nasm_bytecodes+3749, IF_186|IF_NOLONG},
    /*  672 */ {I_POPF, 0, {0,0,0,0,0}, nasm_bytecodes+3753, IF_8086},
    /*  673 */ {I_POPFD, 0, {0,0,0,0,0}, nasm_bytecodes+3757, IF_386|IF_NOLONG},
    /*  674 */ {I_POPFW, 0, {0,0,0,0,0}, nasm_bytecodes+3761, IF_8086},
    /*  675 */ {I_POR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+369, IF_PENT|IF_MMX|IF_SQ},
    /*  676 */ {I_PREFETCH, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2549, IF_PENT|IF_3DNOW|IF_SQ},
    /*  677 */ {I_PREFETCHW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2554, IF_PENT|IF_3DNOW|IF_SQ},
    /*  678 */ {I_PSLLD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+376, IF_PENT|IF_MMX|IF_SQ},
    /*  679 */ {I_PSLLD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+383, IF_PENT|IF_MMX},
    /*  680 */ {I_PSLLQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+390, IF_PENT|IF_MMX|IF_SQ},
    /*  681 */ {I_PSLLQ, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+397, IF_PENT|IF_MMX},
    /*  682 */ {I_PSLLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+404, IF_PENT|IF_MMX|IF_SQ},
    /*  683 */ {I_PSLLW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+411, IF_PENT|IF_MMX},
    /*  684 */ {I_PSRAD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+418, IF_PENT|IF_MMX|IF_SQ},
    /*  685 */ {I_PSRAD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+425, IF_PENT|IF_MMX},
    /*  686 */ {I_PSRAW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+432, IF_PENT|IF_MMX|IF_SQ},
    /*  687 */ {I_PSRAW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+439, IF_PENT|IF_MMX},
    /*  688 */ {I_PSRLD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+446, IF_PENT|IF_MMX|IF_SQ},
    /*  689 */ {I_PSRLD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+453, IF_PENT|IF_MMX},
    /*  690 */ {I_PSRLQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+460, IF_PENT|IF_MMX|IF_SQ},
    /*  691 */ {I_PSRLQ, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+467, IF_PENT|IF_MMX},
    /*  692 */ {I_PSRLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+474, IF_PENT|IF_MMX|IF_SQ},
    /*  693 */ {I_PSRLW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+481, IF_PENT|IF_MMX},
    /*  694 */ {I_PSUBB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+488, IF_PENT|IF_MMX|IF_SQ},
    /*  695 */ {I_PSUBD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+495, IF_PENT|IF_MMX|IF_SQ},
    /*  696 */ {I_PSUBSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+502, IF_PENT|IF_MMX|IF_SQ},
    /*  697 */ {I_PSUBSIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+1236, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    /*  698 */ {I_PSUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+509, IF_PENT|IF_MMX|IF_SQ},
    /*  699 */ {I_PSUBUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+516, IF_PENT|IF_MMX|IF_SQ},
    /*  700 */ {I_PSUBUSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+523, IF_PENT|IF_MMX|IF_SQ},
    /*  701 */ {I_PSUBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+530, IF_PENT|IF_MMX|IF_SQ},
    /*  702 */ {I_PUNPCKHBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+537, IF_PENT|IF_MMX|IF_SQ},
    /*  703 */ {I_PUNPCKHDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+544, IF_PENT|IF_MMX|IF_SQ},
    /*  704 */ {I_PUNPCKHWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+551, IF_PENT|IF_MMX|IF_SQ},
    /*  705 */ {I_PUNPCKLBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+558, IF_PENT|IF_MMX|IF_SQ},
    /*  706 */ {I_PUNPCKLDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+565, IF_PENT|IF_MMX|IF_SQ},
    /*  707 */ {I_PUNPCKLWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+572, IF_PENT|IF_MMX|IF_SQ},
    /*  708 */ {I_PUSH, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+3765, IF_8086},
    /*  709 */ {I_PUSH, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+3769, IF_386|IF_NOLONG},
    /*  710 */ {I_PUSH, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2559, IF_8086},
    /*  711 */ {I_PUSH, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+2564, IF_386|IF_NOLONG},
    /*  712 */ {I_PUSH, 1, {REG_CS,0,0,0,0}, nasm_bytecodes+3535, IF_8086|IF_NOLONG},
    /*  713 */ {I_PUSH, 1, {REG_DESS,0,0,0,0}, nasm_bytecodes+3535, IF_8086|IF_NOLONG},
    /*  714 */ {I_PUSH, 1, {REG_FSGS,0,0,0,0}, nasm_bytecodes+3773, IF_386},
    /*  715 */ {I_PUSH, 1, {IMMEDIATE|BITS8,0,0,0,0}, nasm_bytecodes+3777, IF_186},
    /*  716 */ {I_PUSH, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+2569, IF_186|IF_AR0|IF_SZ},
    /*  717 */ {I_PUSH, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+2574, IF_386|IF_NOLONG|IF_AR0|IF_SZ},
    /*  718 */ {I_PUSH, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+2574, IF_386|IF_NOLONG|IF_SD},
    /*  719 */ {I_PUSHA, 0, {0,0,0,0,0}, nasm_bytecodes+3781, IF_186|IF_NOLONG},
    /*  720 */ {I_PUSHAD, 0, {0,0,0,0,0}, nasm_bytecodes+3785, IF_386|IF_NOLONG},
    /*  721 */ {I_PUSHAW, 0, {0,0,0,0,0}, nasm_bytecodes+3789, IF_186|IF_NOLONG},
    /*  722 */ {I_PUSHF, 0, {0,0,0,0,0}, nasm_bytecodes+3793, IF_8086},
    /*  723 */ {I_PUSHFD, 0, {0,0,0,0,0}, nasm_bytecodes+3797, IF_386|IF_NOLONG},
    /*  724 */ {I_PUSHFW, 0, {0,0,0,0,0}, nasm_bytecodes+3801, IF_8086},
    /*  725 */ {I_PXOR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+579, IF_PENT|IF_MMX|IF_SQ},
    /*  726 */ {I_RCL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3805, IF_8086},
    /*  727 */ {I_RCL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3809, IF_8086},
    /*  728 */ {I_RCL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2579, IF_186|IF_SB},
    /*  729 */ {I_RCL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2584, IF_8086},
    /*  730 */ {I_RCL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2589, IF_8086},
    /*  731 */ {I_RCL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1242, IF_186|IF_SB},
    /*  732 */ {I_RCL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2594, IF_386},
    /*  733 */ {I_RCL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2599, IF_386},
    /*  734 */ {I_RCL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1248, IF_386|IF_SB},
    /*  735 */ {I_RCR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3813, IF_8086},
    /*  736 */ {I_RCR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3817, IF_8086},
    /*  737 */ {I_RCR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2604, IF_186|IF_SB},
    /*  738 */ {I_RCR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2609, IF_8086},
    /*  739 */ {I_RCR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2614, IF_8086},
    /*  740 */ {I_RCR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1254, IF_186|IF_SB},
    /*  741 */ {I_RCR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2619, IF_386},
    /*  742 */ {I_RCR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2624, IF_386},
    /*  743 */ {I_RCR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1260, IF_386|IF_SB},
    /*  744 */ {I_RDSHR, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1266, IF_P6|IF_CYRIX|IF_SMM},
    /*  745 */ {I_RDMSR, 0, {0,0,0,0,0}, nasm_bytecodes+3821, IF_PENT|IF_PRIV},
    /*  746 */ {I_RDPMC, 0, {0,0,0,0,0}, nasm_bytecodes+3825, IF_P6},
    /*  747 */ {I_RDTSC, 0, {0,0,0,0,0}, nasm_bytecodes+3829, IF_PENT},
    /*  748 */ {I_RDTSCP, 0, {0,0,0,0,0}, nasm_bytecodes+2629, IF_X86_64},
    /*  749 */ {I_RET, 0, {0,0,0,0,0}, nasm_bytecodes+4069, IF_8086},
    /*  750 */ {I_RET, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+3833, IF_8086|IF_SW},
    /*  751 */ {I_RETF, 0, {0,0,0,0,0}, nasm_bytecodes+4072, IF_8086},
    /*  752 */ {I_RETF, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+3837, IF_8086|IF_SW},
    /*  753 */ {I_RETN, 0, {0,0,0,0,0}, nasm_bytecodes+4069, IF_8086},
    /*  754 */ {I_RETN, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+3833, IF_8086|IF_SW},
    /*  755 */ {I_ROL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3841, IF_8086},
    /*  756 */ {I_ROL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3845, IF_8086},
    /*  757 */ {I_ROL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2634, IF_186|IF_SB},
    /*  758 */ {I_ROL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2639, IF_8086},
    /*  759 */ {I_ROL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2644, IF_8086},
    /*  760 */ {I_ROL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1272, IF_186|IF_SB},
    /*  761 */ {I_ROL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2649, IF_386},
    /*  762 */ {I_ROL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2654, IF_386},
    /*  763 */ {I_ROL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1278, IF_386|IF_SB},
    /*  764 */ {I_ROR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3849, IF_8086},
    /*  765 */ {I_ROR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3853, IF_8086},
    /*  766 */ {I_ROR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2659, IF_186|IF_SB},
    /*  767 */ {I_ROR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2664, IF_8086},
    /*  768 */ {I_ROR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2669, IF_8086},
    /*  769 */ {I_ROR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1284, IF_186|IF_SB},
    /*  770 */ {I_ROR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2674, IF_386},
    /*  771 */ {I_ROR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2679, IF_386},
    /*  772 */ {I_ROR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1290, IF_386|IF_SB},
    /*  773 */ {I_RSDC, 2, {REG_SREG,MEMORY|BITS80,0,0,0}, nasm_bytecodes+2684, IF_486|IF_CYRIX|IF_SMM},
    /*  774 */ {I_RSLDT, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+2689, IF_486|IF_CYRIX|IF_SMM},
    /*  775 */ {I_RSM, 0, {0,0,0,0,0}, nasm_bytecodes+3857, IF_PENT|IF_SMM},
    /*  776 */ {I_RSTS, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+2694, IF_486|IF_CYRIX|IF_SMM},
    /*  777 */ {I_SAHF, 0, {0,0,0,0,0}, nasm_bytecodes+29, IF_8086},
    /*  778 */ {I_SALC, 0, {0,0,0,0,0}, nasm_bytecodes+4075, IF_8086|IF_UNDOC},
    /*  779 */ {I_SAR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3869, IF_8086},
    /*  780 */ {I_SAR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3873, IF_8086},
    /*  781 */ {I_SAR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2724, IF_186|IF_SB},
    /*  782 */ {I_SAR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2729, IF_8086},
    /*  783 */ {I_SAR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2734, IF_8086},
    /*  784 */ {I_SAR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1308, IF_186|IF_SB},
    /*  785 */ {I_SAR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2739, IF_386},
    /*  786 */ {I_SAR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2744, IF_386},
    /*  787 */ {I_SAR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1314, IF_386|IF_SB},
    /*  788 */ {I_SBB, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3877, IF_8086|IF_SM},
    /*  789 */ {I_SBB, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3877, IF_8086},
    /*  790 */ {I_SBB, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2749, IF_8086|IF_SM},
    /*  791 */ {I_SBB, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2749, IF_8086},
    /*  792 */ {I_SBB, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2754, IF_386|IF_SM},
    /*  793 */ {I_SBB, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2754, IF_386},
    /*  794 */ {I_SBB, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3881, IF_8086|IF_SM},
    /*  795 */ {I_SBB, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3881, IF_8086},
    /*  796 */ {I_SBB, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2759, IF_8086|IF_SM},
    /*  797 */ {I_SBB, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2759, IF_8086},
    /*  798 */ {I_SBB, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2764, IF_386|IF_SM},
    /*  799 */ {I_SBB, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2764, IF_386},
    /*  800 */ {I_SBB, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1320, IF_8086},
    /*  801 */ {I_SBB, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1326, IF_386},
    /*  802 */ {I_SBB, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3885, IF_8086|IF_SM},
    /*  803 */ {I_SBB, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+1320, IF_8086|IF_SM},
    /*  804 */ {I_SBB, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+2769, IF_8086|IF_SM},
    /*  805 */ {I_SBB, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+1326, IF_386|IF_SM},
    /*  806 */ {I_SBB, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+2774, IF_386|IF_SM},
    /*  807 */ {I_SBB, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2779, IF_8086|IF_SM},
    /*  808 */ {I_SBB, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1332, IF_8086|IF_SM},
    /*  809 */ {I_SBB, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1338, IF_386|IF_SM},
    /*  810 */ {I_SBB, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+2779, IF_8086|IF_SM},
    /*  811 */ {I_SBB, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1332, IF_8086|IF_SM},
    /*  812 */ {I_SBB, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1338, IF_386|IF_SM},
    /*  813 */ {I_SCASB, 0, {0,0,0,0,0}, nasm_bytecodes+3889, IF_8086},
    /*  814 */ {I_SCASD, 0, {0,0,0,0,0}, nasm_bytecodes+2784, IF_386},
    /*  815 */ {I_SCASW, 0, {0,0,0,0,0}, nasm_bytecodes+2789, IF_8086},
    /*  816 */ {I_SGDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2794, IF_286},
    /*  817 */ {I_SHL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3861, IF_8086},
    /*  818 */ {I_SHL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3865, IF_8086},
    /*  819 */ {I_SHL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2699, IF_186|IF_SB},
    /*  820 */ {I_SHL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2704, IF_8086},
    /*  821 */ {I_SHL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2709, IF_8086},
    /*  822 */ {I_SHL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1296, IF_186|IF_SB},
    /*  823 */ {I_SHL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2714, IF_386},
    /*  824 */ {I_SHL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2719, IF_386},
    /*  825 */ {I_SHL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1302, IF_386|IF_SB},
    /*  826 */ {I_SHLD, 3, {MEMORY,REG_GPR|BITS16,IMMEDIATE,0,0}, nasm_bytecodes+586, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  827 */ {I_SHLD, 3, {REG_GPR|BITS16,REG_GPR|BITS16,IMMEDIATE,0,0}, nasm_bytecodes+586, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  828 */ {I_SHLD, 3, {MEMORY,REG_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+593, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  829 */ {I_SHLD, 3, {REG_GPR|BITS32,REG_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+593, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  830 */ {I_SHLD, 3, {MEMORY,REG_GPR|BITS16,REG_CL,0,0}, nasm_bytecodes+1344, IF_386|IF_SM},
    /*  831 */ {I_SHLD, 3, {REG_GPR|BITS16,REG_GPR|BITS16,REG_CL,0,0}, nasm_bytecodes+1344, IF_386},
    /*  832 */ {I_SHLD, 3, {MEMORY,REG_GPR|BITS32,REG_CL,0,0}, nasm_bytecodes+1350, IF_386|IF_SM},
    /*  833 */ {I_SHLD, 3, {REG_GPR|BITS32,REG_GPR|BITS32,REG_CL,0,0}, nasm_bytecodes+1350, IF_386},
    /*  834 */ {I_SHR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+3893, IF_8086},
    /*  835 */ {I_SHR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+3897, IF_8086},
    /*  836 */ {I_SHR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2799, IF_186|IF_SB},
    /*  837 */ {I_SHR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+2804, IF_8086},
    /*  838 */ {I_SHR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+2809, IF_8086},
    /*  839 */ {I_SHR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1356, IF_186|IF_SB},
    /*  840 */ {I_SHR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+2814, IF_386},
    /*  841 */ {I_SHR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+2819, IF_386},
    /*  842 */ {I_SHR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1362, IF_386|IF_SB},
    /*  843 */ {I_SHRD, 3, {MEMORY,REG_GPR|BITS16,IMMEDIATE,0,0}, nasm_bytecodes+600, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  844 */ {I_SHRD, 3, {REG_GPR|BITS16,REG_GPR|BITS16,IMMEDIATE,0,0}, nasm_bytecodes+600, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  845 */ {I_SHRD, 3, {MEMORY,REG_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+607, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  846 */ {I_SHRD, 3, {REG_GPR|BITS32,REG_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+607, IF_386|IF_SM2|IF_SB|IF_AR2},
    /*  847 */ {I_SHRD, 3, {MEMORY,REG_GPR|BITS16,REG_CL,0,0}, nasm_bytecodes+1368, IF_386|IF_SM},
    /*  848 */ {I_SHRD, 3, {REG_GPR|BITS16,REG_GPR|BITS16,REG_CL,0,0}, nasm_bytecodes+1368, IF_386},
    /*  849 */ {I_SHRD, 3, {MEMORY,REG_GPR|BITS32,REG_CL,0,0}, nasm_bytecodes+1374, IF_386|IF_SM},
    /*  850 */ {I_SHRD, 3, {REG_GPR|BITS32,REG_GPR|BITS32,REG_CL,0,0}, nasm_bytecodes+1374, IF_386},
    /*  851 */ {I_SIDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2824, IF_286},
    /*  852 */ {I_SLDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+1387, IF_286},
    /*  853 */ {I_SLDT, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+1387, IF_286},
    /*  854 */ {I_SLDT, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1380, IF_286},
    /*  855 */ {I_SLDT, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1386, IF_386},
    /*  856 */ {I_SMI, 0, {0,0,0,0,0}, nasm_bytecodes+4036, IF_386|IF_UNDOC},
    /*  857 */ {I_SMSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+1399, IF_286},
    /*  858 */ {I_SMSW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+1399, IF_286},
    /*  859 */ {I_SMSW, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1392, IF_286},
    /*  860 */ {I_SMSW, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1398, IF_386},
    /*  861 */ {I_STC, 0, {0,0,0,0,0}, nasm_bytecodes+2631, IF_8086},
    /*  862 */ {I_STD, 0, {0,0,0,0,0}, nasm_bytecodes+4078, IF_8086},
    /*  863 */ {I_STI, 0, {0,0,0,0,0}, nasm_bytecodes+4081, IF_8086},
    /*  864 */ {I_STOSB, 0, {0,0,0,0,0}, nasm_bytecodes+133, IF_8086},
    /*  865 */ {I_STOSD, 0, {0,0,0,0,0}, nasm_bytecodes+3909, IF_386},
    /*  866 */ {I_STOSW, 0, {0,0,0,0,0}, nasm_bytecodes+3913, IF_8086},
    /*  867 */ {I_STR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+1411, IF_286|IF_PROT},
    /*  868 */ {I_STR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+1411, IF_286|IF_PROT},
    /*  869 */ {I_STR, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+1404, IF_286|IF_PROT},
    /*  870 */ {I_STR, 1, {REG_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1410, IF_386|IF_PROT},
    /*  871 */ {I_SUB, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3917, IF_8086|IF_SM},
    /*  872 */ {I_SUB, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3917, IF_8086},
    /*  873 */ {I_SUB, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2829, IF_8086|IF_SM},
    /*  874 */ {I_SUB, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2829, IF_8086},
    /*  875 */ {I_SUB, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2834, IF_386|IF_SM},
    /*  876 */ {I_SUB, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2834, IF_386},
    /*  877 */ {I_SUB, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3921, IF_8086|IF_SM},
    /*  878 */ {I_SUB, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3921, IF_8086},
    /*  879 */ {I_SUB, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2839, IF_8086|IF_SM},
    /*  880 */ {I_SUB, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2839, IF_8086},
    /*  881 */ {I_SUB, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2844, IF_386|IF_SM},
    /*  882 */ {I_SUB, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2844, IF_386},
    /*  883 */ {I_SUB, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1416, IF_8086},
    /*  884 */ {I_SUB, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1422, IF_386},
    /*  885 */ {I_SUB, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3925, IF_8086|IF_SM},
    /*  886 */ {I_SUB, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+1416, IF_8086|IF_SM},
    /*  887 */ {I_SUB, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+2849, IF_8086|IF_SM},
    /*  888 */ {I_SUB, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+1422, IF_386|IF_SM},
    /*  889 */ {I_SUB, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+2854, IF_386|IF_SM},
    /*  890 */ {I_SUB, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2859, IF_8086|IF_SM},
    /*  891 */ {I_SUB, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1428, IF_8086|IF_SM},
    /*  892 */ {I_SUB, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1434, IF_386|IF_SM},
    /*  893 */ {I_SUB, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+2859, IF_8086|IF_SM},
    /*  894 */ {I_SUB, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1428, IF_8086|IF_SM},
    /*  895 */ {I_SUB, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1434, IF_386|IF_SM},
    /*  896 */ {I_SVDC, 2, {MEMORY|BITS80,REG_SREG,0,0,0}, nasm_bytecodes+2864, IF_486|IF_CYRIX|IF_SMM},
    /*  897 */ {I_SVTS, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+2874, IF_486|IF_CYRIX|IF_SMM},
    /*  898 */ {I_SYSCALL, 0, {0,0,0,0,0}, nasm_bytecodes+3641, IF_P6|IF_AMD},
    /*  899 */ {I_SYSENTER, 0, {0,0,0,0,0}, nasm_bytecodes+3929, IF_P6},
    /*  900 */ {I_SYSEXIT, 0, {0,0,0,0,0}, nasm_bytecodes+3933, IF_P6|IF_PRIV},
    /*  901 */ {I_SYSRET, 0, {0,0,0,0,0}, nasm_bytecodes+3637, IF_P6|IF_PRIV|IF_AMD},
    /*  902 */ {I_TEST, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3937, IF_8086|IF_SM},
    /*  903 */ {I_TEST, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3937, IF_8086},
    /*  904 */ {I_TEST, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2879, IF_8086|IF_SM},
    /*  905 */ {I_TEST, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2879, IF_8086},
    /*  906 */ {I_TEST, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2884, IF_386|IF_SM},
    /*  907 */ {I_TEST, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2884, IF_386},
    /*  908 */ {I_TEST, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3941, IF_8086|IF_SM},
    /*  909 */ {I_TEST, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2889, IF_8086|IF_SM},
    /*  910 */ {I_TEST, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2894, IF_386|IF_SM},
    /*  911 */ {I_TEST, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+3945, IF_8086|IF_SM},
    /*  912 */ {I_TEST, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+2899, IF_8086|IF_SM},
    /*  913 */ {I_TEST, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+2904, IF_386|IF_SM},
    /*  914 */ {I_TEST, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2909, IF_8086|IF_SM},
    /*  915 */ {I_TEST, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1440, IF_8086|IF_SM},
    /*  916 */ {I_TEST, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1446, IF_386|IF_SM},
    /*  917 */ {I_TEST, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+2909, IF_8086|IF_SM},
    /*  918 */ {I_TEST, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1440, IF_8086|IF_SM},
    /*  919 */ {I_TEST, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1446, IF_386|IF_SM},
    /*  920 */ {I_UD0, 0, {0,0,0,0,0}, nasm_bytecodes+3949, IF_186|IF_UNDOC},
    /*  921 */ {I_UD1, 0, {0,0,0,0,0}, nasm_bytecodes+3953, IF_186|IF_UNDOC},
    /*  922 */ {I_UD2, 0, {0,0,0,0,0}, nasm_bytecodes+3957, IF_186},
    /*  923 */ {I_VERR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2914, IF_286|IF_PROT},
    /*  924 */ {I_VERR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+2914, IF_286|IF_PROT},
    /*  925 */ {I_VERR, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2914, IF_286|IF_PROT},
    /*  926 */ {I_VERW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+2919, IF_286|IF_PROT},
    /*  927 */ {I_VERW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+2919, IF_286|IF_PROT},
    /*  928 */ {I_VERW, 1, {REG_GPR|BITS16,0,0,0,0}, nasm_bytecodes+2919, IF_286|IF_PROT},
    /*  929 */ {I_FWAIT, 0, {0,0,0,0,0}, nasm_bytecodes+3539, IF_8086},
    /*  930 */ {I_WBINVD, 0, {0,0,0,0,0}, nasm_bytecodes+3961, IF_486|IF_PRIV},
    /*  931 */ {I_WRSHR, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+1464, IF_P6|IF_CYRIX|IF_SMM},
    /*  932 */ {I_WRMSR, 0, {0,0,0,0,0}, nasm_bytecodes+3965, IF_PENT|IF_PRIV},
    /*  933 */ {I_XADD, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+2924, IF_486|IF_SM},
    /*  934 */ {I_XADD, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+2924, IF_486},
    /*  935 */ {I_XADD, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1470, IF_486|IF_SM},
    /*  936 */ {I_XADD, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+1470, IF_486},
    /*  937 */ {I_XADD, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1476, IF_486|IF_SM},
    /*  938 */ {I_XADD, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+1476, IF_486},
    /*  939 */ {I_XCHG, 2, {REG_AX,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+3969, IF_8086},
    /*  940 */ {I_XCHG, 2, {REG_EAX,REG32NA,0,0,0}, nasm_bytecodes+3973, IF_386},
    /*  941 */ {I_XCHG, 2, {REG_GPR|BITS16,REG_AX,0,0,0}, nasm_bytecodes+3977, IF_8086},
    /*  942 */ {I_XCHG, 2, {REG32NA,REG_EAX,0,0,0}, nasm_bytecodes+3981, IF_386},
    /*  943 */ {I_XCHG, 2, {REG_EAX,REG_EAX,0,0,0}, nasm_bytecodes+3985, IF_386|IF_NOLONG},
    /*  944 */ {I_XCHG, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+3989, IF_8086|IF_SM},
    /*  945 */ {I_XCHG, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3989, IF_8086},
    /*  946 */ {I_XCHG, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2929, IF_8086|IF_SM},
    /*  947 */ {I_XCHG, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2929, IF_8086},
    /*  948 */ {I_XCHG, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2934, IF_386|IF_SM},
    /*  949 */ {I_XCHG, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2934, IF_386},
    /*  950 */ {I_XCHG, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3993, IF_8086|IF_SM},
    /*  951 */ {I_XCHG, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3993, IF_8086},
    /*  952 */ {I_XCHG, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2939, IF_8086|IF_SM},
    /*  953 */ {I_XCHG, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2939, IF_8086},
    /*  954 */ {I_XCHG, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2944, IF_386|IF_SM},
    /*  955 */ {I_XCHG, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2944, IF_386},
    /*  956 */ {I_XLATB, 0, {0,0,0,0,0}, nasm_bytecodes+4084, IF_8086},
    /*  957 */ {I_XLAT, 0, {0,0,0,0,0}, nasm_bytecodes+4084, IF_8086},
    /*  958 */ {I_XOR, 2, {MEMORY,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3997, IF_8086|IF_SM},
    /*  959 */ {I_XOR, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+3997, IF_8086},
    /*  960 */ {I_XOR, 2, {MEMORY,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2949, IF_8086|IF_SM},
    /*  961 */ {I_XOR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2949, IF_8086},
    /*  962 */ {I_XOR, 2, {MEMORY,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2954, IF_386|IF_SM},
    /*  963 */ {I_XOR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2954, IF_386},
    /*  964 */ {I_XOR, 2, {REG_GPR|BITS8,MEMORY,0,0,0}, nasm_bytecodes+4001, IF_8086|IF_SM},
    /*  965 */ {I_XOR, 2, {REG_GPR|BITS8,REG_GPR|BITS8,0,0,0}, nasm_bytecodes+4001, IF_8086},
    /*  966 */ {I_XOR, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+2959, IF_8086|IF_SM},
    /*  967 */ {I_XOR, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+2959, IF_8086},
    /*  968 */ {I_XOR, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+2964, IF_386|IF_SM},
    /*  969 */ {I_XOR, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+2964, IF_386},
    /*  970 */ {I_XOR, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1494, IF_8086},
    /*  971 */ {I_XOR, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+1500, IF_386},
    /*  972 */ {I_XOR, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+4005, IF_8086|IF_SM},
    /*  973 */ {I_XOR, 2, {REG_AX,SBYTE16,0,0,0}, nasm_bytecodes+1494, IF_8086|IF_SM},
    /*  974 */ {I_XOR, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+2969, IF_8086|IF_SM},
    /*  975 */ {I_XOR, 2, {REG_EAX,SBYTE32,0,0,0}, nasm_bytecodes+1500, IF_386|IF_SM},
    /*  976 */ {I_XOR, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+2974, IF_386|IF_SM},
    /*  977 */ {I_XOR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+2979, IF_8086|IF_SM},
    /*  978 */ {I_XOR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+1506, IF_8086|IF_SM},
    /*  979 */ {I_XOR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+1512, IF_386|IF_SM},
    /*  980 */ {I_XOR, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+2979, IF_8086|IF_SM},
    /*  981 */ {I_XOR, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+1506, IF_8086|IF_SM},
    /*  982 */ {I_XOR, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+1512, IF_386|IF_SM},
    /*  983 */ {I_CMOVcc, 2, {REG_GPR|BITS16,MEMORY,0,0,0}, nasm_bytecodes+642, IF_P6|IF_SM},
    /*  984 */ {I_CMOVcc, 2, {REG_GPR|BITS16,REG_GPR|BITS16,0,0,0}, nasm_bytecodes+642, IF_P6},
    /*  985 */ {I_CMOVcc, 2, {REG_GPR|BITS32,MEMORY,0,0,0}, nasm_bytecodes+649, IF_P6|IF_SM},
    /*  986 */ {I_CMOVcc, 2, {REG_GPR|BITS32,REG_GPR|BITS32,0,0,0}, nasm_bytecodes+649, IF_P6},
    /*  987 */ {I_Jcc, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+656, IF_386},
    /*  988 */ {I_Jcc, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+663, IF_386},
    /*  989 */ {I_Jcc, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+670, IF_386},
    /*  990 */ {I_Jcc, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+2985, IF_8086},
    /*  991 */ {I_SETcc, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+1518, IF_386|IF_SB},
    /*  992 */ {I_SETcc, 1, {REG_GPR|BITS8,0,0,0,0}, nasm_bytecodes+1518, IF_386},
};

static const struct itemplate * const itable_00[] = {
    instrux + 32,
    instrux + 33,
};

static const struct itemplate * const itable_01[] = {
    instrux + 34,
    instrux + 35,
    instrux + 36,
    instrux + 37,
};

static const struct itemplate * const itable_02[] = {
    instrux + 38,
    instrux + 39,
};

static const struct itemplate * const itable_03[] = {
    instrux + 40,
    instrux + 41,
    instrux + 42,
    instrux + 43,
};

static const struct itemplate * const itable_04[] = {
    instrux + 46,
};

static const struct itemplate * const itable_05[] = {
    instrux + 48,
    instrux + 50,
};

static const struct itemplate * const itable_06[] = {
    instrux + 712,
    instrux + 713,
};

static const struct itemplate * const itable_07[] = {
    instrux + 667,
};

static const struct itemplate * const itable_08[] = {
    instrux + 577,
    instrux + 578,
};

static const struct itemplate * const itable_09[] = {
    instrux + 579,
    instrux + 580,
    instrux + 581,
    instrux + 582,
};

static const struct itemplate * const itable_0A[] = {
    instrux + 583,
    instrux + 584,
};

static const struct itemplate * const itable_0B[] = {
    instrux + 585,
    instrux + 586,
    instrux + 587,
    instrux + 588,
};

static const struct itemplate * const itable_0C[] = {
    instrux + 591,
};

static const struct itemplate * const itable_0D[] = {
    instrux + 593,
    instrux + 595,
};

static const struct itemplate * const itable_0E[] = {
    instrux + 712,
    instrux + 713,
};

static const struct itemplate * const itable_0F00[] = {
    instrux + 474,
    instrux + 475,
    instrux + 476,
    instrux + 508,
    instrux + 509,
    instrux + 510,
    instrux + 852,
    instrux + 853,
    instrux + 854,
    instrux + 855,
    instrux + 867,
    instrux + 868,
    instrux + 869,
    instrux + 870,
    instrux + 923,
    instrux + 924,
    instrux + 925,
    instrux + 926,
    instrux + 927,
    instrux + 928,
};

static const struct itemplate * const itable_0F01[] = {
    instrux + 428,
    instrux + 470,
    instrux + 473,
    instrux + 477,
    instrux + 478,
    instrux + 479,
    instrux + 748,
    instrux + 816,
    instrux + 851,
    instrux + 857,
    instrux + 858,
    instrux + 859,
    instrux + 860,
};

static const struct itemplate * const itable_0F02[] = {
    instrux + 455,
    instrux + 456,
    instrux + 457,
    instrux + 458,
    instrux + 459,
    instrux + 460,
};

static const struct itemplate * const itable_0F03[] = {
    instrux + 500,
    instrux + 501,
    instrux + 502,
    instrux + 503,
    instrux + 504,
    instrux + 505,
};

static const struct itemplate * const itable_0F05[] = {
    instrux + 481,
    instrux + 898,
};

static const struct itemplate * const itable_0F06[] = {
    instrux + 146,
};

static const struct itemplate * const itable_0F07[] = {
    instrux + 480,
    instrux + 901,
};

static const struct itemplate * const itable_0F08[] = {
    instrux + 427,
};

static const struct itemplate * const itable_0F09[] = {
    instrux + 930,
};

static const struct itemplate * const itable_0F0B[] = {
    instrux + 922,
};

static const struct itemplate * const itable_0F0D[] = {
    instrux + 676,
    instrux + 677,
};

static const struct itemplate * const itable_0F0E[] = {
    instrux + 267,
};

static const struct itemplate * const itable_0F0F[] = {
    instrux + 626,
    instrux + 634,
    instrux + 635,
    instrux + 636,
    instrux + 637,
    instrux + 638,
    instrux + 639,
    instrux + 640,
    instrux + 641,
    instrux + 642,
    instrux + 643,
    instrux + 644,
    instrux + 645,
    instrux + 646,
    instrux + 647,
    instrux + 648,
    instrux + 649,
    instrux + 650,
    instrux + 655,
};

static const struct itemplate * const itable_0F1F[] = {
    instrux + 572,
    instrux + 573,
};

static const struct itemplate * const itable_0F20[] = {
    instrux + 523,
};

static const struct itemplate * const itable_0F21[] = {
    instrux + 525,
};

static const struct itemplate * const itable_0F22[] = {
    instrux + 524,
};

static const struct itemplate * const itable_0F23[] = {
    instrux + 526,
};

static const struct itemplate * const itable_0F30[] = {
    instrux + 932,
};

static const struct itemplate * const itable_0F31[] = {
    instrux + 747,
};

static const struct itemplate * const itable_0F32[] = {
    instrux + 745,
};

static const struct itemplate * const itable_0F33[] = {
    instrux + 746,
};

static const struct itemplate * const itable_0F34[] = {
    instrux + 899,
};

static const struct itemplate * const itable_0F35[] = {
    instrux + 900,
};

static const struct itemplate * const itable_0F36[] = {
    instrux + 744,
};

static const struct itemplate * const itable_0F37[] = {
    instrux + 931,
};

static const struct itemplate * const itable_0F39[] = {
    instrux + 198,
};

static const struct itemplate * const itable_0F3C[] = {
    instrux + 185,
};

static const struct itemplate * const itable_0F3D[] = {
    instrux + 184,
};

static const struct itemplate * const itable_0F40[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F41[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F42[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F43[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F44[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F45[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F46[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F47[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F48[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F49[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F4A[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F4B[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F4C[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F4D[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F4E[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F4F[] = {
    instrux + 983,
    instrux + 984,
    instrux + 985,
    instrux + 986,
};

static const struct itemplate * const itable_0F50[] = {
    instrux + 625,
};

static const struct itemplate * const itable_0F51[] = {
    instrux + 617,
};

static const struct itemplate * const itable_0F52[] = {
    instrux + 653,
};

static const struct itemplate * const itable_0F54[] = {
    instrux + 633,
};

static const struct itemplate * const itable_0F55[] = {
    instrux + 697,
};

static const struct itemplate * const itable_0F58[] = {
    instrux + 662,
};

static const struct itemplate * const itable_0F59[] = {
    instrux + 656,
};

static const struct itemplate * const itable_0F5A[] = {
    instrux + 661,
};

static const struct itemplate * const itable_0F5B[] = {
    instrux + 660,
};

static const struct itemplate * const itable_0F5C[] = {
    instrux + 659,
};

static const struct itemplate * const itable_0F5D[] = {
    instrux + 654,
};

static const struct itemplate * const itable_0F5E[] = {
    instrux + 651,
};

static const struct itemplate * const itable_0F60[] = {
    instrux + 705,
};

static const struct itemplate * const itable_0F61[] = {
    instrux + 707,
};

static const struct itemplate * const itable_0F62[] = {
    instrux + 706,
};

static const struct itemplate * const itable_0F63[] = {
    instrux + 612,
};

static const struct itemplate * const itable_0F64[] = {
    instrux + 630,
};

static const struct itemplate * const itable_0F65[] = {
    instrux + 632,
};

static const struct itemplate * const itable_0F66[] = {
    instrux + 631,
};

static const struct itemplate * const itable_0F67[] = {
    instrux + 613,
};

static const struct itemplate * const itable_0F68[] = {
    instrux + 702,
};

static const struct itemplate * const itable_0F69[] = {
    instrux + 704,
};

static const struct itemplate * const itable_0F6A[] = {
    instrux + 703,
};

static const struct itemplate * const itable_0F6B[] = {
    instrux + 611,
};

static const struct itemplate * const itable_0F6E[] = {
    instrux + 548,
    instrux + 549,
};

static const struct itemplate * const itable_0F6F[] = {
    instrux + 552,
};

static const struct itemplate * const itable_0F71[] = {
    instrux + 683,
    instrux + 687,
    instrux + 693,
};

static const struct itemplate * const itable_0F72[] = {
    instrux + 679,
    instrux + 685,
    instrux + 689,
};

static const struct itemplate * const itable_0F73[] = {
    instrux + 681,
    instrux + 691,
};

static const struct itemplate * const itable_0F74[] = {
    instrux + 627,
};

static const struct itemplate * const itable_0F75[] = {
    instrux + 629,
};

static const struct itemplate * const itable_0F76[] = {
    instrux + 628,
};

static const struct itemplate * const itable_0F77[] = {
    instrux + 199,
};

static const struct itemplate * const itable_0F78[] = {
    instrux + 896,
};

static const struct itemplate * const itable_0F79[] = {
    instrux + 773,
};

static const struct itemplate * const itable_0F7B[] = {
    instrux + 774,
};

static const struct itemplate * const itable_0F7C[] = {
    instrux + 897,
};

static const struct itemplate * const itable_0F7D[] = {
    instrux + 776,
};

static const struct itemplate * const itable_0F7E[] = {
    instrux + 550,
    instrux + 551,
};

static const struct itemplate * const itable_0F7F[] = {
    instrux + 553,
};

static const struct itemplate * const itable_0F80[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F81[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F82[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F83[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F84[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F85[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F86[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F87[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F88[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F89[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F8A[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F8B[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F8C[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F8D[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F8E[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F8F[] = {
    instrux + 987,
    instrux + 988,
    instrux + 989,
};

static const struct itemplate * const itable_0F90[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F91[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F92[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F93[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F94[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F95[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F96[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F97[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F98[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F99[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F9A[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F9B[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F9C[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F9D[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F9E[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0F9F[] = {
    instrux + 991,
    instrux + 992,
};

static const struct itemplate * const itable_0FA0[] = {
    instrux + 714,
};

static const struct itemplate * const itable_0FA1[] = {
    instrux + 668,
};

static const struct itemplate * const itable_0FA2[] = {
    instrux + 183,
};

static const struct itemplate * const itable_0FA3[] = {
    instrux + 95,
    instrux + 96,
    instrux + 97,
    instrux + 98,
};

static const struct itemplate * const itable_0FA4[] = {
    instrux + 826,
    instrux + 827,
    instrux + 828,
    instrux + 829,
};

static const struct itemplate * const itable_0FA5[] = {
    instrux + 830,
    instrux + 831,
    instrux + 832,
    instrux + 833,
};

static const struct itemplate * const itable_0FA8[] = {
    instrux + 714,
};

static const struct itemplate * const itable_0FA9[] = {
    instrux + 668,
};

static const struct itemplate * const itable_0FAA[] = {
    instrux + 775,
};

static const struct itemplate * const itable_0FAB[] = {
    instrux + 113,
    instrux + 114,
    instrux + 115,
    instrux + 116,
};

static const struct itemplate * const itable_0FAC[] = {
    instrux + 843,
    instrux + 844,
    instrux + 845,
    instrux + 846,
};

static const struct itemplate * const itable_0FAD[] = {
    instrux + 847,
    instrux + 848,
    instrux + 849,
    instrux + 850,
};

static const struct itemplate * const itable_0FAF[] = {
    instrux + 393,
    instrux + 394,
    instrux + 395,
    instrux + 396,
};

static const struct itemplate * const itable_0FB0[] = {
    instrux + 176,
    instrux + 177,
};

static const struct itemplate * const itable_0FB1[] = {
    instrux + 178,
    instrux + 179,
    instrux + 180,
    instrux + 181,
};

static const struct itemplate * const itable_0FB2[] = {
    instrux + 506,
    instrux + 507,
};

static const struct itemplate * const itable_0FB3[] = {
    instrux + 107,
    instrux + 108,
    instrux + 109,
    instrux + 110,
};

static const struct itemplate * const itable_0FB4[] = {
    instrux + 468,
    instrux + 469,
};

static const struct itemplate * const itable_0FB5[] = {
    instrux + 471,
    instrux + 472,
};

static const struct itemplate * const itable_0FB6[] = {
    instrux + 561,
    instrux + 562,
    instrux + 563,
};

static const struct itemplate * const itable_0FB7[] = {
    instrux + 564,
};

static const struct itemplate * const itable_0FB9[] = {
    instrux + 921,
};

static const struct itemplate * const itable_0FBA[] = {
    instrux + 99,
    instrux + 100,
    instrux + 105,
    instrux + 106,
    instrux + 111,
    instrux + 112,
    instrux + 117,
    instrux + 118,
};

static const struct itemplate * const itable_0FBB[] = {
    instrux + 101,
    instrux + 102,
    instrux + 103,
    instrux + 104,
};

static const struct itemplate * const itable_0FBC[] = {
    instrux + 86,
    instrux + 87,
    instrux + 88,
    instrux + 89,
};

static const struct itemplate * const itable_0FBD[] = {
    instrux + 90,
    instrux + 91,
    instrux + 92,
    instrux + 93,
};

static const struct itemplate * const itable_0FBE[] = {
    instrux + 557,
    instrux + 558,
    instrux + 559,
};

static const struct itemplate * const itable_0FBF[] = {
    instrux + 560,
};

static const struct itemplate * const itable_0FC0[] = {
    instrux + 933,
    instrux + 934,
};

static const struct itemplate * const itable_0FC1[] = {
    instrux + 935,
    instrux + 936,
    instrux + 937,
    instrux + 938,
};

static const struct itemplate * const itable_0FC7[] = {
    instrux + 182,
};

static const struct itemplate * const itable_0FC8[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FC9[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FCA[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FCB[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FCC[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FCD[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FCE[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FCF[] = {
    instrux + 94,
};

static const struct itemplate * const itable_0FD1[] = {
    instrux + 692,
};

static const struct itemplate * const itable_0FD2[] = {
    instrux + 688,
};

static const struct itemplate * const itable_0FD3[] = {
    instrux + 690,
};

static const struct itemplate * const itable_0FD5[] = {
    instrux + 658,
};

static const struct itemplate * const itable_0FD8[] = {
    instrux + 699,
};

static const struct itemplate * const itable_0FD9[] = {
    instrux + 700,
};

static const struct itemplate * const itable_0FDB[] = {
    instrux + 622,
};

static const struct itemplate * const itable_0FDC[] = {
    instrux + 619,
};

static const struct itemplate * const itable_0FDD[] = {
    instrux + 620,
};

static const struct itemplate * const itable_0FDF[] = {
    instrux + 623,
};

static const struct itemplate * const itable_0FE1[] = {
    instrux + 686,
};

static const struct itemplate * const itable_0FE2[] = {
    instrux + 684,
};

static const struct itemplate * const itable_0FE5[] = {
    instrux + 657,
};

static const struct itemplate * const itable_0FE8[] = {
    instrux + 696,
};

static const struct itemplate * const itable_0FE9[] = {
    instrux + 698,
};

static const struct itemplate * const itable_0FEB[] = {
    instrux + 675,
};

static const struct itemplate * const itable_0FEC[] = {
    instrux + 616,
};

static const struct itemplate * const itable_0FED[] = {
    instrux + 618,
};

static const struct itemplate * const itable_0FEF[] = {
    instrux + 725,
};

static const struct itemplate * const itable_0FF1[] = {
    instrux + 682,
};

static const struct itemplate * const itable_0FF2[] = {
    instrux + 678,
};

static const struct itemplate * const itable_0FF3[] = {
    instrux + 680,
};

static const struct itemplate * const itable_0FF5[] = {
    instrux + 652,
};

static const struct itemplate * const itable_0FF8[] = {
    instrux + 694,
};

static const struct itemplate * const itable_0FF9[] = {
    instrux + 701,
};

static const struct itemplate * const itable_0FFA[] = {
    instrux + 695,
};

static const struct itemplate * const itable_0FFC[] = {
    instrux + 614,
};

static const struct itemplate * const itable_0FFD[] = {
    instrux + 621,
};

static const struct itemplate * const itable_0FFE[] = {
    instrux + 615,
};

static const struct itemplate * const itable_0FFF[] = {
    instrux + 920,
};

static const struct itemplate * const itable_10[] = {
    instrux + 7,
    instrux + 8,
};

static const struct itemplate * const itable_11[] = {
    instrux + 9,
    instrux + 10,
    instrux + 11,
    instrux + 12,
};

static const struct itemplate * const itable_12[] = {
    instrux + 13,
    instrux + 14,
};

static const struct itemplate * const itable_13[] = {
    instrux + 15,
    instrux + 16,
    instrux + 17,
    instrux + 18,
};

static const struct itemplate * const itable_14[] = {
    instrux + 21,
};

static const struct itemplate * const itable_15[] = {
    instrux + 23,
    instrux + 25,
};

static const struct itemplate * const itable_16[] = {
    instrux + 712,
    instrux + 713,
};

static const struct itemplate * const itable_17[] = {
    instrux + 667,
};

static const struct itemplate * const itable_18[] = {
    instrux + 788,
    instrux + 789,
};

static const struct itemplate * const itable_19[] = {
    instrux + 790,
    instrux + 791,
    instrux + 792,
    instrux + 793,
};

static const struct itemplate * const itable_1A[] = {
    instrux + 794,
    instrux + 795,
};

static const struct itemplate * const itable_1B[] = {
    instrux + 796,
    instrux + 797,
    instrux + 798,
    instrux + 799,
};

static const struct itemplate * const itable_1C[] = {
    instrux + 802,
};

static const struct itemplate * const itable_1D[] = {
    instrux + 804,
    instrux + 806,
};

static const struct itemplate * const itable_1E[] = {
    instrux + 712,
    instrux + 713,
};

static const struct itemplate * const itable_1F[] = {
    instrux + 667,
};

static const struct itemplate * const itable_20[] = {
    instrux + 57,
    instrux + 58,
};

static const struct itemplate * const itable_21[] = {
    instrux + 59,
    instrux + 60,
    instrux + 61,
    instrux + 62,
};

static const struct itemplate * const itable_22[] = {
    instrux + 63,
    instrux + 64,
};

static const struct itemplate * const itable_23[] = {
    instrux + 65,
    instrux + 66,
    instrux + 67,
    instrux + 68,
};

static const struct itemplate * const itable_24[] = {
    instrux + 71,
};

static const struct itemplate * const itable_25[] = {
    instrux + 73,
    instrux + 75,
};

static const struct itemplate * const itable_27[] = {
    instrux + 188,
};

static const struct itemplate * const itable_28[] = {
    instrux + 871,
    instrux + 872,
};

static const struct itemplate * const itable_29[] = {
    instrux + 873,
    instrux + 874,
    instrux + 875,
    instrux + 876,
};

static const struct itemplate * const itable_2A[] = {
    instrux + 877,
    instrux + 878,
};

static const struct itemplate * const itable_2B[] = {
    instrux + 879,
    instrux + 880,
    instrux + 881,
    instrux + 882,
};

static const struct itemplate * const itable_2C[] = {
    instrux + 885,
};

static const struct itemplate * const itable_2D[] = {
    instrux + 887,
    instrux + 889,
};

static const struct itemplate * const itable_2F[] = {
    instrux + 189,
};

static const struct itemplate * const itable_30[] = {
    instrux + 958,
    instrux + 959,
};

static const struct itemplate * const itable_31[] = {
    instrux + 960,
    instrux + 961,
    instrux + 962,
    instrux + 963,
};

static const struct itemplate * const itable_32[] = {
    instrux + 964,
    instrux + 965,
};

static const struct itemplate * const itable_33[] = {
    instrux + 966,
    instrux + 967,
    instrux + 968,
    instrux + 969,
};

static const struct itemplate * const itable_34[] = {
    instrux + 972,
};

static const struct itemplate * const itable_35[] = {
    instrux + 974,
    instrux + 976,
};

static const struct itemplate * const itable_37[] = {
    instrux + 1,
};

static const struct itemplate * const itable_38[] = {
    instrux + 148,
    instrux + 149,
};

static const struct itemplate * const itable_39[] = {
    instrux + 150,
    instrux + 151,
    instrux + 152,
    instrux + 153,
};

static const struct itemplate * const itable_3A[] = {
    instrux + 154,
    instrux + 155,
};

static const struct itemplate * const itable_3B[] = {
    instrux + 156,
    instrux + 157,
    instrux + 158,
    instrux + 159,
};

static const struct itemplate * const itable_3C[] = {
    instrux + 162,
};

static const struct itemplate * const itable_3D[] = {
    instrux + 164,
    instrux + 166,
};

static const struct itemplate * const itable_3F[] = {
    instrux + 6,
};

static const struct itemplate * const itable_40[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_41[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_42[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_43[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_44[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_45[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_46[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_47[] = {
    instrux + 415,
    instrux + 416,
};

static const struct itemplate * const itable_48[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_49[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_4A[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_4B[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_4C[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_4D[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_4E[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_4F[] = {
    instrux + 190,
    instrux + 191,
};

static const struct itemplate * const itable_50[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_51[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_52[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_53[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_54[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_55[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_56[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_57[] = {
    instrux + 708,
    instrux + 709,
};

static const struct itemplate * const itable_58[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_59[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_5A[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_5B[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_5C[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_5D[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_5E[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_5F[] = {
    instrux + 663,
    instrux + 664,
};

static const struct itemplate * const itable_60[] = {
    instrux + 719,
    instrux + 720,
    instrux + 721,
};

static const struct itemplate * const itable_61[] = {
    instrux + 669,
    instrux + 670,
    instrux + 671,
};

static const struct itemplate * const itable_62[] = {
    instrux + 84,
    instrux + 85,
};

static const struct itemplate * const itable_63[] = {
    instrux + 82,
    instrux + 83,
};

static const struct itemplate * const itable_68[] = {
    instrux + 716,
    instrux + 717,
    instrux + 718,
};

static const struct itemplate * const itable_69[] = {
    instrux + 398,
    instrux + 400,
    instrux + 402,
    instrux + 404,
    instrux + 406,
    instrux + 408,
};

static const struct itemplate * const itable_6A[] = {
    instrux + 715,
    instrux + 716,
    instrux + 717,
    instrux + 718,
};

static const struct itemplate * const itable_6B[] = {
    instrux + 397,
    instrux + 399,
    instrux + 401,
    instrux + 403,
    instrux + 405,
    instrux + 407,
};

static const struct itemplate * const itable_6C[] = {
    instrux + 420,
};

static const struct itemplate * const itable_6D[] = {
    instrux + 421,
    instrux + 422,
};

static const struct itemplate * const itable_6E[] = {
    instrux + 608,
};

static const struct itemplate * const itable_6F[] = {
    instrux + 609,
    instrux + 610,
};

static const struct itemplate * const itable_70[] = {
    instrux + 990,
};

static const struct itemplate * const itable_71[] = {
    instrux + 990,
};

static const struct itemplate * const itable_72[] = {
    instrux + 990,
};

static const struct itemplate * const itable_73[] = {
    instrux + 990,
};

static const struct itemplate * const itable_74[] = {
    instrux + 990,
};

static const struct itemplate * const itable_75[] = {
    instrux + 990,
};

static const struct itemplate * const itable_76[] = {
    instrux + 990,
};

static const struct itemplate * const itable_77[] = {
    instrux + 990,
};

static const struct itemplate * const itable_78[] = {
    instrux + 990,
};

static const struct itemplate * const itable_79[] = {
    instrux + 990,
};

static const struct itemplate * const itable_7A[] = {
    instrux + 990,
};

static const struct itemplate * const itable_7B[] = {
    instrux + 990,
};

static const struct itemplate * const itable_7C[] = {
    instrux + 990,
};

static const struct itemplate * const itable_7D[] = {
    instrux + 990,
};

static const struct itemplate * const itable_7E[] = {
    instrux + 990,
};

static const struct itemplate * const itable_7F[] = {
    instrux + 990,
};

static const struct itemplate * const itable_80[] = {
    instrux + 26,
    instrux + 29,
    instrux + 51,
    instrux + 54,
    instrux + 76,
    instrux + 79,
    instrux + 167,
    instrux + 170,
    instrux + 596,
    instrux + 599,
    instrux + 807,
    instrux + 810,
    instrux + 890,
    instrux + 893,
    instrux + 977,
    instrux + 980,
};

static const struct itemplate * const itable_81[] = {
    instrux + 27,
    instrux + 28,
    instrux + 30,
    instrux + 31,
    instrux + 52,
    instrux + 53,
    instrux + 55,
    instrux + 56,
    instrux + 77,
    instrux + 78,
    instrux + 80,
    instrux + 81,
    instrux + 168,
    instrux + 169,
    instrux + 171,
    instrux + 172,
    instrux + 597,
    instrux + 598,
    instrux + 600,
    instrux + 601,
    instrux + 808,
    instrux + 809,
    instrux + 811,
    instrux + 812,
    instrux + 891,
    instrux + 892,
    instrux + 894,
    instrux + 895,
    instrux + 978,
    instrux + 979,
    instrux + 981,
    instrux + 982,
};

static const struct itemplate * const itable_83[] = {
    instrux + 19,
    instrux + 20,
    instrux + 22,
    instrux + 24,
    instrux + 27,
    instrux + 28,
    instrux + 30,
    instrux + 31,
    instrux + 44,
    instrux + 45,
    instrux + 47,
    instrux + 49,
    instrux + 52,
    instrux + 53,
    instrux + 55,
    instrux + 56,
    instrux + 69,
    instrux + 70,
    instrux + 72,
    instrux + 74,
    instrux + 77,
    instrux + 78,
    instrux + 80,
    instrux + 81,
    instrux + 160,
    instrux + 161,
    instrux + 163,
    instrux + 165,
    instrux + 168,
    instrux + 169,
    instrux + 171,
    instrux + 172,
    instrux + 589,
    instrux + 590,
    instrux + 592,
    instrux + 594,
    instrux + 597,
    instrux + 598,
    instrux + 600,
    instrux + 601,
    instrux + 800,
    instrux + 801,
    instrux + 803,
    instrux + 805,
    instrux + 808,
    instrux + 809,
    instrux + 811,
    instrux + 812,
    instrux + 883,
    instrux + 884,
    instrux + 886,
    instrux + 888,
    instrux + 891,
    instrux + 892,
    instrux + 894,
    instrux + 895,
    instrux + 970,
    instrux + 971,
    instrux + 973,
    instrux + 975,
    instrux + 978,
    instrux + 979,
    instrux + 981,
    instrux + 982,
};

static const struct itemplate * const itable_84[] = {
    instrux + 902,
    instrux + 903,
    instrux + 908,
};

static const struct itemplate * const itable_85[] = {
    instrux + 904,
    instrux + 905,
    instrux + 906,
    instrux + 907,
    instrux + 909,
    instrux + 910,
};

static const struct itemplate * const itable_86[] = {
    instrux + 944,
    instrux + 945,
    instrux + 950,
    instrux + 951,
};

static const struct itemplate * const itable_87[] = {
    instrux + 946,
    instrux + 947,
    instrux + 948,
    instrux + 949,
    instrux + 952,
    instrux + 953,
    instrux + 954,
    instrux + 955,
};

static const struct itemplate * const itable_88[] = {
    instrux + 527,
    instrux + 528,
};

static const struct itemplate * const itable_89[] = {
    instrux + 529,
    instrux + 530,
    instrux + 531,
    instrux + 532,
};

static const struct itemplate * const itable_8A[] = {
    instrux + 533,
    instrux + 534,
};

static const struct itemplate * const itable_8B[] = {
    instrux + 535,
    instrux + 536,
    instrux + 537,
    instrux + 538,
};

static const struct itemplate * const itable_8C[] = {
    instrux + 511,
    instrux + 512,
    instrux + 513,
};

static const struct itemplate * const itable_8D[] = {
    instrux + 463,
    instrux + 464,
};

static const struct itemplate * const itable_8E[] = {
    instrux + 514,
    instrux + 515,
    instrux + 516,
};

static const struct itemplate * const itable_8F[] = {
    instrux + 665,
    instrux + 666,
};

static const struct itemplate * const itable_90[] = {
    instrux + 571,
    instrux + 624,
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
    instrux + 943,
};

static const struct itemplate * const itable_91[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_92[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_93[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_94[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_95[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_96[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_97[] = {
    instrux + 939,
    instrux + 940,
    instrux + 941,
    instrux + 942,
};

static const struct itemplate * const itable_98[] = {
    instrux + 141,
    instrux + 187,
};

static const struct itemplate * const itable_99[] = {
    instrux + 142,
    instrux + 186,
};

static const struct itemplate * const itable_9A[] = {
    instrux + 125,
    instrux + 126,
    instrux + 127,
    instrux + 128,
    instrux + 129,
};

static const struct itemplate * const itable_9C[] = {
    instrux + 722,
    instrux + 723,
    instrux + 724,
};

static const struct itemplate * const itable_9D[] = {
    instrux + 672,
    instrux + 673,
    instrux + 674,
};

static const struct itemplate * const itable_9E[] = {
    instrux + 777,
};

static const struct itemplate * const itable_9F[] = {
    instrux + 454,
};

static const struct itemplate * const itable_A0[] = {
    instrux + 517,
};

static const struct itemplate * const itable_A1[] = {
    instrux + 518,
    instrux + 519,
};

static const struct itemplate * const itable_A2[] = {
    instrux + 520,
};

static const struct itemplate * const itable_A3[] = {
    instrux + 521,
    instrux + 522,
};

static const struct itemplate * const itable_A4[] = {
    instrux + 554,
};

static const struct itemplate * const itable_A5[] = {
    instrux + 555,
    instrux + 556,
};

static const struct itemplate * const itable_A6[] = {
    instrux + 173,
};

static const struct itemplate * const itable_A7[] = {
    instrux + 174,
    instrux + 175,
};

static const struct itemplate * const itable_A8[] = {
    instrux + 911,
};

static const struct itemplate * const itable_A9[] = {
    instrux + 912,
    instrux + 913,
};

static const struct itemplate * const itable_AA[] = {
    instrux + 864,
};

static const struct itemplate * const itable_AB[] = {
    instrux + 865,
    instrux + 866,
};

static const struct itemplate * const itable_AC[] = {
    instrux + 482,
};

static const struct itemplate * const itable_AD[] = {
    instrux + 483,
    instrux + 484,
};

static const struct itemplate * const itable_AE[] = {
    instrux + 813,
};

static const struct itemplate * const itable_AF[] = {
    instrux + 814,
    instrux + 815,
};

static const struct itemplate * const itable_B0[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B1[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B2[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B3[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B4[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B5[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B6[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B7[] = {
    instrux + 539,
};

static const struct itemplate * const itable_B8[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_B9[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_BA[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_BB[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_BC[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_BD[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_BE[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_BF[] = {
    instrux + 540,
    instrux + 541,
};

static const struct itemplate * const itable_C0[] = {
    instrux + 728,
    instrux + 737,
    instrux + 757,
    instrux + 766,
    instrux + 781,
    instrux + 819,
    instrux + 836,
};

static const struct itemplate * const itable_C1[] = {
    instrux + 731,
    instrux + 734,
    instrux + 740,
    instrux + 743,
    instrux + 760,
    instrux + 763,
    instrux + 769,
    instrux + 772,
    instrux + 784,
    instrux + 787,
    instrux + 822,
    instrux + 825,
    instrux + 839,
    instrux + 842,
};

static const struct itemplate * const itable_C2[] = {
    instrux + 750,
    instrux + 754,
};

static const struct itemplate * const itable_C3[] = {
    instrux + 749,
    instrux + 753,
};

static const struct itemplate * const itable_C4[] = {
    instrux + 466,
    instrux + 467,
};

static const struct itemplate * const itable_C5[] = {
    instrux + 461,
    instrux + 462,
};

static const struct itemplate * const itable_C6[] = {
    instrux + 542,
    instrux + 545,
};

static const struct itemplate * const itable_C7[] = {
    instrux + 543,
    instrux + 544,
    instrux + 546,
    instrux + 547,
};

static const struct itemplate * const itable_C8[] = {
    instrux + 200,
};

static const struct itemplate * const itable_C9[] = {
    instrux + 465,
};

static const struct itemplate * const itable_CA[] = {
    instrux + 752,
};

static const struct itemplate * const itable_CB[] = {
    instrux + 751,
};

static const struct itemplate * const itable_CC[] = {
    instrux + 425,
};

static const struct itemplate * const itable_CD[] = {
    instrux + 423,
};

static const struct itemplate * const itable_CE[] = {
    instrux + 426,
};

static const struct itemplate * const itable_CF[] = {
    instrux + 429,
    instrux + 430,
    instrux + 431,
};

static const struct itemplate * const itable_D0[] = {
    instrux + 726,
    instrux + 735,
    instrux + 755,
    instrux + 764,
    instrux + 779,
    instrux + 817,
    instrux + 834,
};

static const struct itemplate * const itable_D1[] = {
    instrux + 729,
    instrux + 732,
    instrux + 738,
    instrux + 741,
    instrux + 758,
    instrux + 761,
    instrux + 767,
    instrux + 770,
    instrux + 782,
    instrux + 785,
    instrux + 820,
    instrux + 823,
    instrux + 837,
    instrux + 840,
};

static const struct itemplate * const itable_D2[] = {
    instrux + 727,
    instrux + 736,
    instrux + 756,
    instrux + 765,
    instrux + 780,
    instrux + 818,
    instrux + 835,
};

static const struct itemplate * const itable_D3[] = {
    instrux + 730,
    instrux + 733,
    instrux + 739,
    instrux + 742,
    instrux + 759,
    instrux + 762,
    instrux + 768,
    instrux + 771,
    instrux + 783,
    instrux + 786,
    instrux + 821,
    instrux + 824,
    instrux + 838,
    instrux + 841,
};

static const struct itemplate * const itable_D4[] = {
    instrux + 4,
    instrux + 5,
};

static const struct itemplate * const itable_D5[] = {
    instrux + 2,
    instrux + 3,
};

static const struct itemplate * const itable_D6[] = {
    instrux + 778,
};

static const struct itemplate * const itable_D7[] = {
    instrux + 956,
    instrux + 957,
};

static const struct itemplate * const itable_D8[] = {
    instrux + 205,
    instrux + 208,
    instrux + 210,
    instrux + 235,
    instrux + 237,
    instrux + 238,
    instrux + 243,
    instrux + 245,
    instrux + 246,
    instrux + 251,
    instrux + 254,
    instrux + 256,
    instrux + 259,
    instrux + 263,
    instrux + 264,
    instrux + 312,
    instrux + 316,
    instrux + 317,
    instrux + 353,
    instrux + 357,
    instrux + 358,
    instrux + 361,
    instrux + 365,
    instrux + 366,
};

static const struct itemplate * const itable_D9[] = {
    instrux + 203,
    instrux + 204,
    instrux + 217,
    instrux + 248,
    instrux + 249,
    instrux + 288,
    instrux + 299,
    instrux + 302,
    instrux + 303,
    instrux + 304,
    instrux + 305,
    instrux + 306,
    instrux + 307,
    instrux + 308,
    instrux + 309,
    instrux + 310,
    instrux + 311,
    instrux + 324,
    instrux + 326,
    instrux + 327,
    instrux + 330,
    instrux + 331,
    instrux + 332,
    instrux + 333,
    instrux + 334,
    instrux + 337,
    instrux + 339,
    instrux + 340,
    instrux + 341,
    instrux + 342,
    instrux + 345,
    instrux + 346,
    instrux + 347,
    instrux + 369,
    instrux + 379,
    instrux + 380,
    instrux + 381,
    instrux + 382,
    instrux + 383,
    instrux + 384,
    instrux + 385,
};

static const struct itemplate * const itable_DA[] = {
    instrux + 219,
    instrux + 220,
    instrux + 221,
    instrux + 222,
    instrux + 223,
    instrux + 224,
    instrux + 233,
    instrux + 234,
    instrux + 273,
    instrux + 275,
    instrux + 277,
    instrux + 279,
    instrux + 281,
    instrux + 286,
    instrux + 295,
    instrux + 297,
    instrux + 378,
};

static const struct itemplate * const itable_DB[] = {
    instrux + 218,
    instrux + 225,
    instrux + 226,
    instrux + 227,
    instrux + 228,
    instrux + 229,
    instrux + 230,
    instrux + 231,
    instrux + 232,
    instrux + 239,
    instrux + 240,
    instrux + 250,
    instrux + 268,
    instrux + 283,
    instrux + 289,
    instrux + 290,
    instrux + 292,
    instrux + 301,
    instrux + 320,
    instrux + 321,
    instrux + 322,
    instrux + 323,
    instrux + 338,
    instrux + 349,
    instrux + 372,
    instrux + 373,
};

static const struct itemplate * const itable_DC[] = {
    instrux + 206,
    instrux + 207,
    instrux + 209,
    instrux + 236,
    instrux + 244,
    instrux + 252,
    instrux + 253,
    instrux + 255,
    instrux + 260,
    instrux + 261,
    instrux + 262,
    instrux + 313,
    instrux + 314,
    instrux + 315,
    instrux + 354,
    instrux + 355,
    instrux + 356,
    instrux + 362,
    instrux + 363,
    instrux + 364,
};

static const struct itemplate * const itable_DD[] = {
    instrux + 269,
    instrux + 270,
    instrux + 300,
    instrux + 325,
    instrux + 328,
    instrux + 335,
    instrux + 336,
    instrux + 343,
    instrux + 344,
    instrux + 348,
    instrux + 350,
    instrux + 351,
    instrux + 370,
    instrux + 371,
    instrux + 376,
    instrux + 377,
};

static const struct itemplate * const itable_DE[] = {
    instrux + 211,
    instrux + 212,
    instrux + 247,
    instrux + 257,
    instrux + 258,
    instrux + 265,
    instrux + 266,
    instrux + 274,
    instrux + 276,
    instrux + 278,
    instrux + 280,
    instrux + 282,
    instrux + 287,
    instrux + 296,
    instrux + 298,
    instrux + 318,
    instrux + 319,
    instrux + 359,
    instrux + 360,
    instrux + 367,
    instrux + 368,
};

static const struct itemplate * const itable_DF[] = {
    instrux + 213,
    instrux + 214,
    instrux + 215,
    instrux + 216,
    instrux + 241,
    instrux + 242,
    instrux + 271,
    instrux + 272,
    instrux + 284,
    instrux + 285,
    instrux + 291,
    instrux + 293,
    instrux + 294,
    instrux + 329,
    instrux + 352,
    instrux + 374,
    instrux + 375,
};

static const struct itemplate * const itable_E0[] = {
    instrux + 491,
    instrux + 492,
    instrux + 493,
    instrux + 494,
    instrux + 495,
    instrux + 496,
};

static const struct itemplate * const itable_E1[] = {
    instrux + 488,
    instrux + 489,
    instrux + 490,
    instrux + 497,
    instrux + 498,
    instrux + 499,
};

static const struct itemplate * const itable_E2[] = {
    instrux + 485,
    instrux + 486,
    instrux + 487,
};

static const struct itemplate * const itable_E3[] = {
    instrux + 432,
    instrux + 433,
};

static const struct itemplate * const itable_E4[] = {
    instrux + 409,
};

static const struct itemplate * const itable_E5[] = {
    instrux + 410,
    instrux + 411,
};

static const struct itemplate * const itable_E6[] = {
    instrux + 602,
};

static const struct itemplate * const itable_E7[] = {
    instrux + 603,
    instrux + 604,
};

static const struct itemplate * const itable_E8[] = {
    instrux + 119,
    instrux + 120,
    instrux + 121,
    instrux + 122,
    instrux + 123,
    instrux + 124,
};

static const struct itemplate * const itable_E9[] = {
    instrux + 435,
    instrux + 436,
    instrux + 437,
};

static const struct itemplate * const itable_EA[] = {
    instrux + 438,
    instrux + 439,
    instrux + 440,
    instrux + 441,
    instrux + 442,
};

static const struct itemplate * const itable_EB[] = {
    instrux + 434,
};

static const struct itemplate * const itable_EC[] = {
    instrux + 412,
};

static const struct itemplate * const itable_ED[] = {
    instrux + 413,
    instrux + 414,
};

static const struct itemplate * const itable_EE[] = {
    instrux + 605,
};

static const struct itemplate * const itable_EF[] = {
    instrux + 606,
    instrux + 607,
};

static const struct itemplate * const itable_F1[] = {
    instrux + 424,
    instrux + 856,
};

static const struct itemplate * const itable_F4[] = {
    instrux + 386,
};

static const struct itemplate * const itable_F5[] = {
    instrux + 147,
};

static const struct itemplate * const itable_F6[] = {
    instrux + 195,
    instrux + 387,
    instrux + 390,
    instrux + 565,
    instrux + 568,
    instrux + 574,
    instrux + 914,
    instrux + 917,
};

static const struct itemplate * const itable_F7[] = {
    instrux + 196,
    instrux + 197,
    instrux + 388,
    instrux + 389,
    instrux + 391,
    instrux + 392,
    instrux + 566,
    instrux + 567,
    instrux + 569,
    instrux + 570,
    instrux + 575,
    instrux + 576,
    instrux + 915,
    instrux + 916,
    instrux + 918,
    instrux + 919,
};

static const struct itemplate * const itable_F8[] = {
    instrux + 143,
};

static const struct itemplate * const itable_F9[] = {
    instrux + 861,
};

static const struct itemplate * const itable_FA[] = {
    instrux + 145,
};

static const struct itemplate * const itable_FB[] = {
    instrux + 863,
};

static const struct itemplate * const itable_FC[] = {
    instrux + 144,
};

static const struct itemplate * const itable_FD[] = {
    instrux + 862,
};

static const struct itemplate * const itable_FE[] = {
    instrux + 192,
    instrux + 417,
};

static const struct itemplate * const itable_FF[] = {
    instrux + 130,
    instrux + 131,
    instrux + 132,
    instrux + 133,
    instrux + 134,
    instrux + 135,
    instrux + 136,
    instrux + 137,
    instrux + 138,
    instrux + 139,
    instrux + 140,
    instrux + 193,
    instrux + 194,
    instrux + 418,
    instrux + 419,
    instrux + 443,
    instrux + 444,
    instrux + 445,
    instrux + 446,
    instrux + 447,
    instrux + 448,
    instrux + 449,
    instrux + 450,
    instrux + 451,
    instrux + 452,
    instrux + 453,
    instrux + 710,
    instrux + 711,
};

static const struct disasm_index itable_0F[256] = {
    /* 0x00 */ { itable_0F00, 20 },
    /* 0x01 */ { itable_0F01, 13 },
    /* 0x02 */ { itable_0F02, 6 },
    /* 0x03 */ { itable_0F03, 6 },
    /* 0x04 */ { NULL, 0 },
    /* 0x05 */ { itable_0F05, 2 },
    /* 0x06 */ { itable_0F06, 1 },
    /* 0x07 */ { itable_0F07, 2 },
    /* 0x08 */ { itable_0F08, 1 },
    /* 0x09 */ { itable_0F09, 1 },
    /* 0x0a */ { NULL, 0 },
    /* 0x0b */ { itable_0F0B, 1 },
    /* 0x0c */ { NULL, 0 },
    /* 0x0d */ { itable_0F0D, 2 },
    /* 0x0e */ { itable_0F0E, 1 },
    /* 0x0f */ { itable_0F0F, 19 },
    /* 0x10 */ { NULL, 0 },
    /* 0x11 */ { NULL, 0 },
    /* 0x12 */ { NULL, 0 },
    /* 0x13 */ { NULL, 0 },
    /* 0x14 */ { NULL, 0 },
    /* 0x15 */ { NULL, 0 },
    /* 0x16 */ { NULL, 0 },
    /* 0x17 */ { NULL, 0 },
    /* 0x18 */ { NULL, 0 },
    /* 0x19 */ { NULL, 0 },
    /* 0x1a */ { NULL, 0 },
    /* 0x1b */ { NULL, 0 },
    /* 0x1c */ { NULL, 0 },
    /* 0x1d */ { NULL, 0 },
    /* 0x1e */ { NULL, 0 },
    /* 0x1f */ { itable_0F1F, 2 },
    /* 0x20 */ { itable_0F20, 1 },
    /* 0x21 */ { itable_0F21, 1 },
    /* 0x22 */ { itable_0F22, 1 },
    /* 0x23 */ { itable_0F23, 1 },
    /* 0x24 */ { NULL, 0 },
    /* 0x25 */ { NULL, 0 },
    /* 0x26 */ { NULL, 0 },
    /* 0x27 */ { NULL, 0 },
    /* 0x28 */ { NULL, 0 },
    /* 0x29 */ { NULL, 0 },
    /* 0x2a */ { NULL, 0 },
    /* 0x2b */ { NULL, 0 },
    /* 0x2c */ { NULL, 0 },
    /* 0x2d */ { NULL, 0 },
    /* 0x2e */ { NULL, 0 },
    /* 0x2f */ { NULL, 0 },
    /* 0x30 */ { itable_0F30, 1 },
    /* 0x31 */ { itable_0F31, 1 },
    /* 0x32 */ { itable_0F32, 1 },
    /* 0x33 */ { itable_0F33, 1 },
    /* 0x34 */ { itable_0F34, 1 },
    /* 0x35 */ { itable_0F35, 1 },
    /* 0x36 */ { itable_0F36, 1 },
    /* 0x37 */ { itable_0F37, 1 },
    /* 0x38 */ { NULL, 0 },
    /* 0x39 */ { itable_0F39, 1 },
    /* 0x3a */ { NULL, 0 },
    /* 0x3b */ { NULL, 0 },
    /* 0x3c */ { itable_0F3C, 1 },
    /* 0x3d */ { itable_0F3D, 1 },
    /* 0x3e */ { NULL, 0 },
    /* 0x3f */ { NULL, 0 },
    /* 0x40 */ { itable_0F40, 4 },
    /* 0x41 */ { itable_0F41, 4 },
    /* 0x42 */ { itable_0F42, 4 },
    /* 0x43 */ { itable_0F43, 4 },
    /* 0x44 */ { itable_0F44, 4 },
    /* 0x45 */ { itable_0F45, 4 },
    /* 0x46 */ { itable_0F46, 4 },
    /* 0x47 */ { itable_0F47, 4 },
    /* 0x48 */ { itable_0F48, 4 },
    /* 0x49 */ { itable_0F49, 4 },
    /* 0x4a */ { itable_0F4A, 4 },
    /* 0x4b */ { itable_0F4B, 4 },
    /* 0x4c */ { itable_0F4C, 4 },
    /* 0x4d */ { itable_0F4D, 4 },
    /* 0x4e */ { itable_0F4E, 4 },
    /* 0x4f */ { itable_0F4F, 4 },
    /* 0x50 */ { itable_0F50, 1 },
    /* 0x51 */ { itable_0F51, 1 },
    /* 0x52 */ { itable_0F52, 1 },
    /* 0x53 */ { NULL, 0 },
    /* 0x54 */ { itable_0F54, 1 },
    /* 0x55 */ { itable_0F55, 1 },
    /* 0x56 */ { NULL, 0 },
    /* 0x57 */ { NULL, 0 },
    /* 0x58 */ { itable_0F58, 1 },
    /* 0x59 */ { itable_0F59, 1 },
    /* 0x5a */ { itable_0F5A, 1 },
    /* 0x5b */ { itable_0F5B, 1 },
    /* 0x5c */ { itable_0F5C, 1 },
    /* 0x5d */ { itable_0F5D, 1 },
    /* 0x5e */ { itable_0F5E, 1 },
    /* 0x5f */ { NULL, 0 },
    /* 0x60 */ { itable_0F60, 1 },
    /* 0x61 */ { itable_0F61, 1 },
    /* 0x62 */ { itable_0F62, 1 },
    /* 0x63 */ { itable_0F63, 1 },
    /* 0x64 */ { itable_0F64, 1 },
    /* 0x65 */ { itable_0F65, 1 },
    /* 0x66 */ { itable_0F66, 1 },
    /* 0x67 */ { itable_0F67, 1 },
    /* 0x68 */ { itable_0F68, 1 },
    /* 0x69 */ { itable_0F69, 1 },
    /* 0x6a */ { itable_0F6A, 1 },
    /* 0x6b */ { itable_0F6B, 1 },
    /* 0x6c */ { NULL, 0 },
    /* 0x6d */ { NULL, 0 },
    /* 0x6e */ { itable_0F6E, 2 },
    /* 0x6f */ { itable_0F6F, 1 },
    /* 0x70 */ { NULL, 0 },
    /* 0x71 */ { itable_0F71, 3 },
    /* 0x72 */ { itable_0F72, 3 },
    /* 0x73 */ { itable_0F73, 2 },
    /* 0x74 */ { itable_0F74, 1 },
    /* 0x75 */ { itable_0F75, 1 },
    /* 0x76 */ { itable_0F76, 1 },
    /* 0x77 */ { itable_0F77, 1 },
    /* 0x78 */ { itable_0F78, 1 },
    /* 0x79 */ { itable_0F79, 1 },
    /* 0x7a */ { NULL, 0 },
    /* 0x7b */ { itable_0F7B, 1 },
    /* 0x7c */ { itable_0F7C, 1 },
    /* 0x7d */ { itable_0F7D, 1 },
    /* 0x7e */ { itable_0F7E, 2 },
    /* 0x7f */ { itable_0F7F, 1 },
    /* 0x80 */ { itable_0F80, 3 },
    /* 0x81 */ { itable_0F81, 3 },
    /* 0x82 */ { itable_0F82, 3 },
    /* 0x83 */ { itable_0F83, 3 },
    /* 0x84 */ { itable_0F84, 3 },
    /* 0x85 */ { itable_0F85, 3 },
    /* 0x86 */ { itable_0F86, 3 },
    /* 0x87 */ { itable_0F87, 3 },
    /* 0x88 */ { itable_0F88, 3 },
    /* 0x89 */ { itable_0F89, 3 },
    /* 0x8a */ { itable_0F8A, 3 },
    /* 0x8b */ { itable_0F8B, 3 },
    /* 0x8c */ { itable_0F8C, 3 },
    /* 0x8d */ { itable_0F8D, 3 },
    /* 0x8e */ { itable_0F8E, 3 },
    /* 0x8f */ { itable_0F8F, 3 },
    /* 0x90 */ { itable_0F90, 2 },
    /* 0x91 */ { itable_0F91, 2 },
    /* 0x92 */ { itable_0F92, 2 },
    /* 0x93 */ { itable_0F93, 2 },
    /* 0x94 */ { itable_0F94, 2 },
    /* 0x95 */ { itable_0F95, 2 },
    /* 0x96 */ { itable_0F96, 2 },
    /* 0x97 */ { itable_0F97, 2 },
    /* 0x98 */ { itable_0F98, 2 },
    /* 0x99 */ { itable_0F99, 2 },
    /* 0x9a */ { itable_0F9A, 2 },
    /* 0x9b */ { itable_0F9B, 2 },
    /* 0x9c */ { itable_0F9C, 2 },
    /* 0x9d */ { itable_0F9D, 2 },
    /* 0x9e */ { itable_0F9E, 2 },
    /* 0x9f */ { itable_0F9F, 2 },
    /* 0xa0 */ { itable_0FA0, 1 },
    /* 0xa1 */ { itable_0FA1, 1 },
    /* 0xa2 */ { itable_0FA2, 1 },
    /* 0xa3 */ { itable_0FA3, 4 },
    /* 0xa4 */ { itable_0FA4, 4 },
    /* 0xa5 */ { itable_0FA5, 4 },
    /* 0xa6 */ { NULL, 0 },
    /* 0xa7 */ { NULL, 0 },
    /* 0xa8 */ { itable_0FA8, 1 },
    /* 0xa9 */ { itable_0FA9, 1 },
    /* 0xaa */ { itable_0FAA, 1 },
    /* 0xab */ { itable_0FAB, 4 },
    /* 0xac */ { itable_0FAC, 4 },
    /* 0xad */ { itable_0FAD, 4 },
    /* 0xae */ { NULL, 0 },
    /* 0xaf */ { itable_0FAF, 4 },
    /* 0xb0 */ { itable_0FB0, 2 },
    /* 0xb1 */ { itable_0FB1, 4 },
    /* 0xb2 */ { itable_0FB2, 2 },
    /* 0xb3 */ { itable_0FB3, 4 },
    /* 0xb4 */ { itable_0FB4, 2 },
    /* 0xb5 */ { itable_0FB5, 2 },
    /* 0xb6 */ { itable_0FB6, 3 },
    /* 0xb7 */ { itable_0FB7, 1 },
    /* 0xb8 */ { NULL, 0 },
    /* 0xb9 */ { itable_0FB9, 1 },
    /* 0xba */ { itable_0FBA, 8 },
    /* 0xbb */ { itable_0FBB, 4 },
    /* 0xbc */ { itable_0FBC, 4 },
    /* 0xbd */ { itable_0FBD, 4 },
    /* 0xbe */ { itable_0FBE, 3 },
    /* 0xbf */ { itable_0FBF, 1 },
    /* 0xc0 */ { itable_0FC0, 2 },
    /* 0xc1 */ { itable_0FC1, 4 },
    /* 0xc2 */ { NULL, 0 },
    /* 0xc3 */ { NULL, 0 },
    /* 0xc4 */ { NULL, 0 },
    /* 0xc5 */ { NULL, 0 },
    /* 0xc6 */ { NULL, 0 },
    /* 0xc7 */ { itable_0FC7, 1 },
    /* 0xc8 */ { itable_0FC8, 1 },
    /* 0xc9 */ { itable_0FC9, 1 },
    /* 0xca */ { itable_0FCA, 1 },
    /* 0xcb */ { itable_0FCB, 1 },
    /* 0xcc */ { itable_0FCC, 1 },
    /* 0xcd */ { itable_0FCD, 1 },
    /* 0xce */ { itable_0FCE, 1 },
    /* 0xcf */ { itable_0FCF, 1 },
    /* 0xd0 */ { NULL, 0 },
    /* 0xd1 */ { itable_0FD1, 1 },
    /* 0xd2 */ { itable_0FD2, 1 },
    /* 0xd3 */ { itable_0FD3, 1 },
    /* 0xd4 */ { NULL, 0 },
    /* 0xd5 */ { itable_0FD5, 1 },
    /* 0xd6 */ { NULL, 0 },
    /* 0xd7 */ { NULL, 0 },
    /* 0xd8 */ { itable_0FD8, 1 },
    /* 0xd9 */ { itable_0FD9, 1 },
    /* 0xda */ { NULL, 0 },
    /* 0xdb */ { itable_0FDB, 1 },
    /* 0xdc */ { itable_0FDC, 1 },
    /* 0xdd */ { itable_0FDD, 1 },
    /* 0xde */ { NULL, 0 },
    /* 0xdf */ { itable_0FDF, 1 },
    /* 0xe0 */ { NULL, 0 },
    /* 0xe1 */ { itable_0FE1, 1 },
    /* 0xe2 */ { itable_0FE2, 1 },
    /* 0xe3 */ { NULL, 0 },
    /* 0xe4 */ { NULL, 0 },
    /* 0xe5 */ { itable_0FE5, 1 },
    /* 0xe6 */ { NULL, 0 },
    /* 0xe7 */ { NULL, 0 },
    /* 0xe8 */ { itable_0FE8, 1 },
    /* 0xe9 */ { itable_0FE9, 1 },
    /* 0xea */ { NULL, 0 },
    /* 0xeb */ { itable_0FEB, 1 },
    /* 0xec */ { itable_0FEC, 1 },
    /* 0xed */ { itable_0FED, 1 },
    /* 0xee */ { NULL, 0 },
    /* 0xef */ { itable_0FEF, 1 },
    /* 0xf0 */ { NULL, 0 },
    /* 0xf1 */ { itable_0FF1, 1 },
    /* 0xf2 */ { itable_0FF2, 1 },
    /* 0xf3 */ { itable_0FF3, 1 },
    /* 0xf4 */ { NULL, 0 },
    /* 0xf5 */ { itable_0FF5, 1 },
    /* 0xf6 */ { NULL, 0 },
    /* 0xf7 */ { NULL, 0 },
    /* 0xf8 */ { itable_0FF8, 1 },
    /* 0xf9 */ { itable_0FF9, 1 },
    /* 0xfa */ { itable_0FFA, 1 },
    /* 0xfb */ { NULL, 0 },
    /* 0xfc */ { itable_0FFC, 1 },
    /* 0xfd */ { itable_0FFD, 1 },
    /* 0xfe */ { itable_0FFE, 1 },
    /* 0xff */ { itable_0FFF, 1 },
};

const struct disasm_index itable[256] = {
    /* 0x00 */ { itable_00, 2 },
    /* 0x01 */ { itable_01, 4 },
    /* 0x02 */ { itable_02, 2 },
    /* 0x03 */ { itable_03, 4 },
    /* 0x04 */ { itable_04, 1 },
    /* 0x05 */ { itable_05, 2 },
    /* 0x06 */ { itable_06, 2 },
    /* 0x07 */ { itable_07, 1 },
    /* 0x08 */ { itable_08, 2 },
    /* 0x09 */ { itable_09, 4 },
    /* 0x0a */ { itable_0A, 2 },
    /* 0x0b */ { itable_0B, 4 },
    /* 0x0c */ { itable_0C, 1 },
    /* 0x0d */ { itable_0D, 2 },
    /* 0x0e */ { itable_0E, 2 },
    /* 0x0f */ { itable_0F, -1 },
    /* 0x10 */ { itable_10, 2 },
    /* 0x11 */ { itable_11, 4 },
    /* 0x12 */ { itable_12, 2 },
    /* 0x13 */ { itable_13, 4 },
    /* 0x14 */ { itable_14, 1 },
    /* 0x15 */ { itable_15, 2 },
    /* 0x16 */ { itable_16, 2 },
    /* 0x17 */ { itable_17, 1 },
    /* 0x18 */ { itable_18, 2 },
    /* 0x19 */ { itable_19, 4 },
    /* 0x1a */ { itable_1A, 2 },
    /* 0x1b */ { itable_1B, 4 },
    /* 0x1c */ { itable_1C, 1 },
    /* 0x1d */ { itable_1D, 2 },
    /* 0x1e */ { itable_1E, 2 },
    /* 0x1f */ { itable_1F, 1 },
    /* 0x20 */ { itable_20, 2 },
    /* 0x21 */ { itable_21, 4 },
    /* 0x22 */ { itable_22, 2 },
    /* 0x23 */ { itable_23, 4 },
    /* 0x24 */ { itable_24, 1 },
    /* 0x25 */ { itable_25, 2 },
    /* 0x26 */ { NULL, 0 },
    /* 0x27 */ { itable_27, 1 },
    /* 0x28 */ { itable_28, 2 },
    /* 0x29 */ { itable_29, 4 },
    /* 0x2a */ { itable_2A, 2 },
    /* 0x2b */ { itable_2B, 4 },
    /* 0x2c */ { itable_2C, 1 },
    /* 0x2d */ { itable_2D, 2 },
    /* 0x2e */ { NULL, 0 },
    /* 0x2f */ { itable_2F, 1 },
    /* 0x30 */ { itable_30, 2 },
    /* 0x31 */ { itable_31, 4 },
    /* 0x32 */ { itable_32, 2 },
    /* 0x33 */ { itable_33, 4 },
    /* 0x34 */ { itable_34, 1 },
    /* 0x35 */ { itable_35, 2 },
    /* 0x36 */ { NULL, 0 },
    /* 0x37 */ { itable_37, 1 },
    /* 0x38 */ { itable_38, 2 },
    /* 0x39 */ { itable_39, 4 },
    /* 0x3a */ { itable_3A, 2 },
    /* 0x3b */ { itable_3B, 4 },
    /* 0x3c */ { itable_3C, 1 },
    /* 0x3d */ { itable_3D, 2 },
    /* 0x3e */ { NULL, 0 },
    /* 0x3f */ { itable_3F, 1 },
    /* 0x40 */ { itable_40, 2 },
    /* 0x41 */ { itable_41, 2 },
    /* 0x42 */ { itable_42, 2 },
    /* 0x43 */ { itable_43, 2 },
    /* 0x44 */ { itable_44, 2 },
    /* 0x45 */ { itable_45, 2 },
    /* 0x46 */ { itable_46, 2 },
    /* 0x47 */ { itable_47, 2 },
    /* 0x48 */ { itable_48, 2 },
    /* 0x49 */ { itable_49, 2 },
    /* 0x4a */ { itable_4A, 2 },
    /* 0x4b */ { itable_4B, 2 },
    /* 0x4c */ { itable_4C, 2 },
    /* 0x4d */ { itable_4D, 2 },
    /* 0x4e */ { itable_4E, 2 },
    /* 0x4f */ { itable_4F, 2 },
    /* 0x50 */ { itable_50, 2 },
    /* 0x51 */ { itable_51, 2 },
    /* 0x52 */ { itable_52, 2 },
    /* 0x53 */ { itable_53, 2 },
    /* 0x54 */ { itable_54, 2 },
    /* 0x55 */ { itable_55, 2 },
    /* 0x56 */ { itable_56, 2 },
    /* 0x57 */ { itable_57, 2 },
    /* 0x58 */ { itable_58, 2 },
    /* 0x59 */ { itable_59, 2 },
    /* 0x5a */ { itable_5A, 2 },
    /* 0x5b */ { itable_5B, 2 },
    /* 0x5c */ { itable_5C, 2 },
    /* 0x5d */ { itable_5D, 2 },
    /* 0x5e */ { itable_5E, 2 },
    /* 0x5f */ { itable_5F, 2 },
    /* 0x60 */ { itable_60, 3 },
    /* 0x61 */ { itable_61, 3 },
    /* 0x62 */ { itable_62, 2 },
    /* 0x63 */ { itable_63, 2 },
    /* 0x64 */ { NULL, 0 },
    /* 0x65 */ { NULL, 0 },
    /* 0x66 */ { NULL, 0 },
    /* 0x67 */ { NULL, 0 },
    /* 0x68 */ { itable_68, 3 },
    /* 0x69 */ { itable_69, 6 },
    /* 0x6a */ { itable_6A, 4 },
    /* 0x6b */ { itable_6B, 6 },
    /* 0x6c */ { itable_6C, 1 },
    /* 0x6d */ { itable_6D, 2 },
    /* 0x6e */ { itable_6E, 1 },
    /* 0x6f */ { itable_6F, 2 },
    /* 0x70 */ { itable_70, 1 },
    /* 0x71 */ { itable_71, 1 },
    /* 0x72 */ { itable_72, 1 },
    /* 0x73 */ { itable_73, 1 },
    /* 0x74 */ { itable_74, 1 },
    /* 0x75 */ { itable_75, 1 },
    /* 0x76 */ { itable_76, 1 },
    /* 0x77 */ { itable_77, 1 },
    /* 0x78 */ { itable_78, 1 },
    /* 0x79 */ { itable_79, 1 },
    /* 0x7a */ { itable_7A, 1 },
    /* 0x7b */ { itable_7B, 1 },
    /* 0x7c */ { itable_7C, 1 },
    /* 0x7d */ { itable_7D, 1 },
    /* 0x7e */ { itable_7E, 1 },
    /* 0x7f */ { itable_7F, 1 },
    /* 0x80 */ { itable_80, 16 },
    /* 0x81 */ { itable_81, 32 },
    /* 0x82 */ { NULL, 0 },
    /* 0x83 */ { itable_83, 64 },
    /* 0x84 */ { itable_84, 3 },
    /* 0x85 */ { itable_85, 6 },
    /* 0x86 */ { itable_86, 4 },
    /* 0x87 */ { itable_87, 8 },
    /* 0x88 */ { itable_88, 2 },
    /* 0x89 */ { itable_89, 4 },
    /* 0x8a */ { itable_8A, 2 },
    /* 0x8b */ { itable_8B, 4 },
    /* 0x8c */ { itable_8C, 3 },
    /* 0x8d */ { itable_8D, 2 },
    /* 0x8e */ { itable_8E, 3 },
    /* 0x8f */ { itable_8F, 2 },
    /* 0x90 */ { itable_90, 7 },
    /* 0x91 */ { itable_91, 4 },
    /* 0x92 */ { itable_92, 4 },
    /* 0x93 */ { itable_93, 4 },
    /* 0x94 */ { itable_94, 4 },
    /* 0x95 */ { itable_95, 4 },
    /* 0x96 */ { itable_96, 4 },
    /* 0x97 */ { itable_97, 4 },
    /* 0x98 */ { itable_98, 2 },
    /* 0x99 */ { itable_99, 2 },
    /* 0x9a */ { itable_9A, 5 },
    /* 0x9b */ { NULL, 0 },
    /* 0x9c */ { itable_9C, 3 },
    /* 0x9d */ { itable_9D, 3 },
    /* 0x9e */ { itable_9E, 1 },
    /* 0x9f */ { itable_9F, 1 },
    /* 0xa0 */ { itable_A0, 1 },
    /* 0xa1 */ { itable_A1, 2 },
    /* 0xa2 */ { itable_A2, 1 },
    /* 0xa3 */ { itable_A3, 2 },
    /* 0xa4 */ { itable_A4, 1 },
    /* 0xa5 */ { itable_A5, 2 },
    /* 0xa6 */ { itable_A6, 1 },
    /* 0xa7 */ { itable_A7, 2 },
    /* 0xa8 */ { itable_A8, 1 },
    /* 0xa9 */ { itable_A9, 2 },
    /* 0xaa */ { itable_AA, 1 },
    /* 0xab */ { itable_AB, 2 },
    /* 0xac */ { itable_AC, 1 },
    /* 0xad */ { itable_AD, 2 },
    /* 0xae */ { itable_AE, 1 },
    /* 0xaf */ { itable_AF, 2 },
    /* 0xb0 */ { itable_B0, 1 },
    /* 0xb1 */ { itable_B1, 1 },
    /* 0xb2 */ { itable_B2, 1 },
    /* 0xb3 */ { itable_B3, 1 },
    /* 0xb4 */ { itable_B4, 1 },
    /* 0xb5 */ { itable_B5, 1 },
    /* 0xb6 */ { itable_B6, 1 },
    /* 0xb7 */ { itable_B7, 1 },
    /* 0xb8 */ { itable_B8, 2 },
    /* 0xb9 */ { itable_B9, 2 },
    /* 0xba */ { itable_BA, 2 },
    /* 0xbb */ { itable_BB, 2 },
    /* 0xbc */ { itable_BC, 2 },
    /* 0xbd */ { itable_BD, 2 },
    /* 0xbe */ { itable_BE, 2 },
    /* 0xbf */ { itable_BF, 2 },
    /* 0xc0 */ { itable_C0, 7 },
    /* 0xc1 */ { itable_C1, 14 },
    /* 0xc2 */ { itable_C2, 2 },
    /* 0xc3 */ { itable_C3, 2 },
    /* 0xc4 */ { itable_C4, 2 },
    /* 0xc5 */ { itable_C5, 2 },
    /* 0xc6 */ { itable_C6, 2 },
    /* 0xc7 */ { itable_C7, 4 },
    /* 0xc8 */ { itable_C8, 1 },
    /* 0xc9 */ { itable_C9, 1 },
    /* 0xca */ { itable_CA, 1 },
    /* 0xcb */ { itable_CB, 1 },
    /* 0xcc */ { itable_CC, 1 },
    /* 0xcd */ { itable_CD, 1 },
    /* 0xce */ { itable_CE, 1 },
    /* 0xcf */ { itable_CF, 3 },
    /* 0xd0 */ { itable_D0, 7 },
    /* 0xd1 */ { itable_D1, 14 },
    /* 0xd2 */ { itable_D2, 7 },
    /* 0xd3 */ { itable_D3, 14 },
    /* 0xd4 */ { itable_D4, 2 },
    /* 0xd5 */ { itable_D5, 2 },
    /* 0xd6 */ { itable_D6, 1 },
    /* 0xd7 */ { itable_D7, 2 },
    /* 0xd8 */ { itable_D8, 24 },
    /* 0xd9 */ { itable_D9, 41 },
    /* 0xda */ { itable_DA, 17 },
    /* 0xdb */ { itable_DB, 26 },
    /* 0xdc */ { itable_DC, 20 },
    /* 0xdd */ { itable_DD, 16 },
    /* 0xde */ { itable_DE, 21 },
    /* 0xdf */ { itable_DF, 17 },
    /* 0xe0 */ { itable_E0, 6 },
    /* 0xe1 */ { itable_E1, 6 },
    /* 0xe2 */ { itable_E2, 3 },
    /* 0xe3 */ { itable_E3, 2 },
    /* 0xe4 */ { itable_E4, 1 },
    /* 0xe5 */ { itable_E5, 2 },
    /* 0xe6 */ { itable_E6, 1 },
    /* 0xe7 */ { itable_E7, 2 },
    /* 0xe8 */ { itable_E8, 6 },
    /* 0xe9 */ { itable_E9, 3 },
    /* 0xea */ { itable_EA, 5 },
    /* 0xeb */ { itable_EB, 1 },
    /* 0xec */ { itable_EC, 1 },
    /* 0xed */ { itable_ED, 2 },
    /* 0xee */ { itable_EE, 1 },
    /* 0xef */ { itable_EF, 2 },
    /* 0xf0 */ { NULL, 0 },
    /* 0xf1 */ { itable_F1, 2 },
    /* 0xf2 */ { NULL, 0 },
    /* 0xf3 */ { NULL, 0 },
    /* 0xf4 */ { itable_F4, 1 },
    /* 0xf5 */ { itable_F5, 1 },
    /* 0xf6 */ { itable_F6, 8 },
    /* 0xf7 */ { itable_F7, 16 },
    /* 0xf8 */ { itable_F8, 1 },
    /* 0xf9 */ { itable_F9, 1 },
    /* 0xfa */ { itable_FA, 1 },
    /* 0xfb */ { itable_FB, 1 },
    /* 0xfc */ { itable_FC, 1 },
    /* 0xfd */ { itable_FD, 1 },
    /* 0xfe */ { itable_FE, 2 },
    /* 0xff */ { itable_FF, 28 },
};

const struct disasm_index * const itable_vex[2][32][4] =
{
    {
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
    },
    {
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
        { NULL,          NULL,          NULL,          NULL,          },
    },
};
