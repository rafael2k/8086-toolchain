#ifndef __ARCH_8086_BORDER_H
#define __ARCH_8086_BORDER_H

extern unsigned long int htonl(unsigned long int);
extern unsigned long int ntohl(unsigned long int);

#endif
