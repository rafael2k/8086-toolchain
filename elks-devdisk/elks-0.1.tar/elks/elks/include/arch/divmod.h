#ifndef __ARCH_8086_DIVMOD_H
#define __ARCH_8086_DIVMOD_H

unsigned long __divmod(unsigned long val, unsigned int *baserem);

#endif
