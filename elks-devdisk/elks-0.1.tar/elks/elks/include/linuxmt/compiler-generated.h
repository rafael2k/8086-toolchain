#define UTS_RELEASE "0.9.0-dev"
#define UTS_VERSION "commit ffff4b5c 10 Dec 2024 23:26:38 +0000"
