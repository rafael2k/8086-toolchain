#ifndef __LINUXMT_RD_H
#define __LINUXMT_RD_H

#define RDCREATE	((1<<8)|0)
#define RDDESTROY	((1<<8)|1)

#endif
