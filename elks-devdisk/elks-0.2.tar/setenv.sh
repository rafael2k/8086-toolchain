#!/bin/sh

echo "Run this script in /root:"
echo ". setenv.sh"

export TOPDIR=/root/elks
export C86LIB=/root/libc
export PATH=$PATH:/root/bin
