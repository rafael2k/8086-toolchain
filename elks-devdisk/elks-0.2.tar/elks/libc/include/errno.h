#ifndef	__ERRNO_H
#define	__ERRNO_H

#include <features.h>
#include __SYSINC__(errno.h)

extern int errno;

#endif
