#ifndef __SYS_PARAM_H
#define __SYS_PARAM_H

#include <limits.h>

#define MAXSYMLINKS 8

#endif
