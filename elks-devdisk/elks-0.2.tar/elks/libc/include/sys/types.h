#ifndef _SYS_TYPES_H
#define _SYS_TYPES_H

#include <features.h>
#include __SYSINC__(types.h)

#endif
