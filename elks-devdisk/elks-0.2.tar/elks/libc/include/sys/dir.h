/* backwards-compatible pre-POSIX header - use <dirent.h> instead*/
#include <dirent.h>

#define direct dirent
