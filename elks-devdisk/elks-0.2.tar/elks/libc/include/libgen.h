#ifndef __LIBGEN_H
#define __LIBGEN_H

char *dirname(char *path);
char *basename(char *path);

#endif /* __LIBGEN_H */
