
/* Absolute file name for network data base files*/
#define _PATH_HOSTS		"/etc/hosts"
#define _PATH_RESOLV	"/etc/resolv.cfg"
