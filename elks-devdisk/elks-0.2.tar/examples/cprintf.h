#ifndef CPRINTF_H_
#define CPRINTF_H_

#include <stdarg.h>

void cprintf(const char *format, ...);

#endif
